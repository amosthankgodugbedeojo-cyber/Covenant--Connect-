package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Denomination
import com.example.data.model.MemberProfile
import com.example.data.model.PrivacySettings
import com.example.data.model.RelationshipIntent
import com.example.data.remote.SupabaseConfig
import com.example.ui.components.FaithTagPill
import com.example.ui.components.ProfileAvatar
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GoldSoftContainer
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.theme.VerifiedEmerald
import com.example.ui.theme.VerifiedEmeraldContainer
import com.example.ui.viewmodel.CovenantUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileTab(
    state: CovenantUiState,
    onUpdatePhotoUri: (String) -> Unit,
    onUpdateProfile: (MemberProfile) -> Unit,
    onOpenSafetyCenter: () -> Unit,
    onSignOut: () -> Unit
) {
    val user = state.currentUser
    var showEditSheet by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onUpdatePhotoUri(uri.toString())
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Profile Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, GoldRoyal.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        ProfileAvatar(profile = user, size = 104.dp, showGoldRing = true)
                        Surface(
                            shape = CircleShape,
                            color = NavyDeep,
                            border = BorderStroke(1.5.dp, GoldBright),
                            modifier = Modifier
                                .size(36.dp)
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                .testTag("profile_pick_photo_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.AddAPhoto,
                                    contentDescription = "Update profile photo",
                                    tint = GoldBright,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${user.fullName}, ${user.age}",
                            style = MaterialTheme.typography.headlineSmall,
                            color = NavyDeep
                        )
                        if (user.emailVerified) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Filled.Verified,
                                contentDescription = "Verified account",
                                tint = GoldRoyal,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = null,
                            tint = TextSecondarySlate,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${user.location} • ${user.gender.label}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondarySlate
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = NavyDeep
                    ) {
                        Text(
                            text = user.denomination,
                            style = MaterialTheme.typography.labelMedium,
                            color = GoldBright,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedButton(
                        onClick = { showEditSheet = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("profile_edit_button"),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, NavyDeep)
                    ) {
                        Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Edit Profile & Faith Details", color = NavyDeep)
                    }
                }
            }
        }

        // Personal Details & Bio Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Faith, Calling & Story",
                        style = MaterialTheme.typography.titleMedium,
                        color = NavyDeep
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Work, contentDescription = null, tint = GoldDeep, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(user.occupation, style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.School, contentDescription = null, tint = GoldDeep, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(user.education, style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Relationship Intention",
                        style = MaterialTheme.typography.labelMedium,
                        color = GoldDeep
                    )
                    Text(
                        text = user.relationshipIntent.label,
                        style = MaterialTheme.typography.titleSmall,
                        color = NavyDeep
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Biography",
                        style = MaterialTheme.typography.labelMedium,
                        color = GoldDeep
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = user.bio,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondarySlate
                    )

                    if (user.favoriteVerse.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = GoldSoftContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "\"${user.favoriteVerse}\"",
                                style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                                color = NavyDeep,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    if (user.faithAndValues.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            user.faithAndValues.forEach { FaithTagPill(it) }
                        }
                    }
                }
            }
        }

        // Supabase Integration Readiness Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.CloudQueue,
                            contentDescription = null,
                            tint = if (state.isSupabaseConfigured) VerifiedEmerald else GoldDeep
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Supabase Backend Readiness",
                            style = MaterialTheme.typography.titleMedium,
                            color = NavyDeep
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (state.isSupabaseConfigured) VerifiedEmeraldContainer else GoldSoftContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (state.isSupabaseConfigured) {
                                "SUPABASE_URL & SUPABASE_ANON_KEY detected via Secrets."
                            } else {
                                "Waiting for SUPABASE_URL & SUPABASE_ANON_KEY in AI Studio Secrets."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (state.isSupabaseConfigured) VerifiedEmerald else NavyDeep,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    SupabaseConfig.expectedTables.forEach { table ->
                        Row(
                            modifier = Modifier.padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = GoldRoyal,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${table.tableName}: ",
                                style = MaterialTheme.typography.labelMedium,
                                color = NavyDeep
                            )
                            Text(
                                text = table.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondarySlate
                            )
                        }
                    }
                }
            }
        }

        // Safety & Privacy Center Button + Sign Out
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenSafetyCenter)
                    .testTag("profile_safety_center_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, GoldRoyal.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Shield, contentDescription = null, tint = NavyDeep)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Safety, Privacy & Blocked Accounts",
                            style = MaterialTheme.typography.titleSmall,
                            color = NavyDeep
                        )
                        Text(
                            text = "${state.blockedUserIds.size} blocked • Privacy protection active",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate
                        )
                    }
                    Text("Manage", color = GoldDeep, style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        item {
            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("profile_sign_out_button"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, AlertCrimson.copy(alpha = 0.6f))
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = null,
                    tint = AlertCrimson,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Exit to Welcome Screen", color = AlertCrimson, fontWeight = FontWeight.SemiBold)
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    if (showEditSheet) {
        EditProfileSheet(
            profile = user,
            onDismiss = { showEditSheet = false },
            onSave = { updated ->
                onUpdateProfile(updated)
                showEditSheet = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun EditProfileSheet(
    profile: MemberProfile,
    onDismiss: () -> Unit,
    onSave: (MemberProfile) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var fullName by remember { mutableStateOf(profile.fullName) }
    var location by remember { mutableStateOf(profile.location) }
    var denomination by remember { mutableStateOf(profile.denomination) }
    var occupation by remember { mutableStateOf(profile.occupation) }
    var education by remember { mutableStateOf(profile.education) }
    var intent by remember { mutableStateOf(profile.relationshipIntent) }
    var bio by remember { mutableStateOf(profile.bio) }
    var favoriteVerse by remember { mutableStateOf(profile.favoriteVerse) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = PureWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Edit Member Profile",
                style = MaterialTheme.typography.headlineSmall,
                color = NavyDeep
            )
            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Full Name") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Location (City, State)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = occupation,
                onValueChange = { occupation = it },
                label = { Text("Occupation") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = education,
                onValueChange = { education = it },
                label = { Text("Educational Background") },
                modifier = Modifier.fillMaxWidth()
            )
            Text("Church Denomination", style = MaterialTheme.typography.labelLarge, color = NavyDeep)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Denomination.entries.forEach { item ->
                    FilterChip(
                        selected = denomination == item.label,
                        onClick = { denomination = item.label },
                        label = { Text(item.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NavyDeep,
                            selectedLabelColor = GoldBright
                        )
                    )
                }
            }

            Text("Relationship Intentions", style = MaterialTheme.typography.labelLarge, color = NavyDeep)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                RelationshipIntent.entries.forEach { option ->
                    FilterChip(
                        selected = intent == option,
                        onClick = { intent = option },
                        label = { Text(option.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldSoftContainer,
                            selectedLabelColor = GoldDeep
                        )
                    )
                }
            }

            OutlinedTextField(
                value = bio,
                onValueChange = { bio = it },
                label = { Text("Personal Biography & Testimony") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5
            )
            OutlinedTextField(
                value = favoriteVerse,
                onValueChange = { favoriteVerse = it },
                label = { Text("Favorite Bible Verse") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    onSave(
                        profile.copy(
                            fullName = fullName.trim().ifBlank { profile.fullName },
                            location = location.trim().ifBlank { profile.location },
                            denomination = denomination,
                            occupation = occupation.trim().ifBlank { profile.occupation },
                            education = education.trim().ifBlank { profile.education },
                            relationshipIntent = intent,
                            bio = bio.trim(),
                            favoriteVerse = favoriteVerse.trim()
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_profile_button"),
                colors = ButtonDefaults.buttonColors(containerColor = NavyDeep)
            ) {
                Text("Save Profile Changes", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafetyPrivacySheet(
    state: CovenantUiState,
    onDismiss: () -> Unit,
    onUpdatePrivacy: (PrivacySettings) -> Unit,
    onUnblockUser: (String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val privacy = state.privacySettings

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = PureWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Shield, contentDescription = null, tint = NavyDeep)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Safety & Privacy Center",
                    style = MaterialTheme.typography.headlineSmall,
                    color = NavyDeep
                )
            }

            // Privacy Toggles
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Lock, contentDescription = null, tint = GoldDeep, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Private Information Protection", style = MaterialTheme.typography.titleSmall, color = NavyDeep)
                    }
                    PrivacyToggleRow(
                        title = "Show City Only (Hide Exact Location)",
                        subtitle = "Only your city and state are visible on Discover cards.",
                        checked = privacy.showCityOnly,
                        onCheckedChange = { onUpdatePrivacy(privacy.copy(showCityOnly = it)) }
                    )
                    PrivacyToggleRow(
                        title = "Mask Email & Contact Info",
                        subtitle = "Your email address is never shared with other members.",
                        checked = privacy.hideEmailFromMembers,
                        onCheckedChange = { onUpdatePrivacy(privacy.copy(hideEmailFromMembers = it)) }
                    )
                    PrivacyToggleRow(
                        title = "Allow Intro Notes with Requests",
                        subtitle = "Let members include an encouraging message when expressing interest.",
                        checked = privacy.allowPrayerNotesOnLikes,
                        onCheckedChange = { onUpdatePrivacy(privacy.copy(allowPrayerNotesOnLikes = it)) }
                    )
                }
            }

            // Blocked Accounts
            Text(
                text = "Blocked Accounts (${state.blockedMembers.size})",
                style = MaterialTheme.typography.titleMedium,
                color = NavyDeep
            )
            if (state.blockedMembers.isEmpty()) {
                Text(
                    text = "You haven't blocked any accounts. You can block or report any member from their profile or chat header.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate
                )
            } else {
                state.blockedMembers.forEach { member ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(member.fullName, style = MaterialTheme.typography.titleSmall, color = NavyDeep)
                                Text(member.location, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
                            }
                            TextButton(onClick = { onUnblockUser(member.id) }) {
                                Text("Unblock", color = GoldDeep)
                            }
                        }
                    }
                }
            }

            HorizontalDivider()

            // Community Guidelines
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Gavel, contentDescription = null, tint = GoldDeep, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Community Guidelines & Privacy Notice",
                    style = MaterialTheme.typography.titleMedium,
                    color = NavyDeep
                )
            }
            Text(
                text = "• Christ-Centered Conduct: Treat every member with dignity, purity, honesty, and grace (Ephesians 4:29).\n" +
                    "• Zero Tolerance: Harassment, deceptive identities, inappropriate imagery, and financial solicitation result in immediate removal.\n" +
                    "• Privacy First: Personal email addresses, birth dates, and private messages are never sold or exposed publicly.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondarySlate
            )
        }
    }
}

@Composable
private fun PrivacyToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, color = NavyDeep)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondarySlate)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = GoldBright,
                checkedTrackColor = NavyDeep
            )
        )
    }
}
