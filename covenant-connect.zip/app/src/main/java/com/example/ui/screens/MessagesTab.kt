package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ChatMessage
import com.example.data.model.MatchRecord
import com.example.data.model.MemberProfile
import com.example.ui.components.ProfileAvatar
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GoldSoftContainer
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyMedium
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.viewmodel.CovenantUiState

@Composable
fun MessagesTab(
    state: CovenantUiState,
    onOpenChat: (String) -> Unit,
    onCloseChat: () -> Unit,
    onSendMessage: (String, String) -> Unit,
    onOpenProfileDetail: (MemberProfile) -> Unit,
    onReportOrBlock: (MemberProfile) -> Unit
) {
    val matches = state.visibleMatches
    val activeMatch = matches.firstOrNull { it.id == state.activeChatMatchId }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideLayout = maxWidth >= 840.dp

        if (isWideLayout) {
            // Canonical List-Detail layout for Tablets / Foldables
            Row(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .width(340.dp)
                        .fillMaxHeight()
                ) {
                    ConversationsList(
                        matches = matches,
                        selectedMatchId = activeMatch?.id,
                        isPreviewMode = state.isPreviewMode,
                        onSelectMatch = onOpenChat
                    )
                }
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.outline)
                )
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    if (activeMatch != null) {
                        ChatConversationPane(
                            match = activeMatch,
                            messages = state.messagesByMatchId[activeMatch.id].orEmpty(),
                            isPreviewMode = state.isPreviewMode,
                            showBackButton = false,
                            onBack = onCloseChat,
                            onSendMessage = { onSendMessage(activeMatch.id, it) },
                            onOpenProfile = { onOpenProfileDetail(activeMatch.matchedMember) },
                            onReportOrBlock = { onReportOrBlock(activeMatch.matchedMember) }
                        )
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Select a match to begin a Christ-centered conversation",
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextSecondarySlate
                            )
                        }
                    }
                }
            }
        } else {
            if (activeMatch != null) {
                BackHandler { onCloseChat() }
                ChatConversationPane(
                    match = activeMatch,
                    messages = state.messagesByMatchId[activeMatch.id].orEmpty(),
                    isPreviewMode = state.isPreviewMode,
                    showBackButton = true,
                    onBack = onCloseChat,
                    onSendMessage = { onSendMessage(activeMatch.id, it) },
                    onOpenProfile = { onOpenProfileDetail(activeMatch.matchedMember) },
                    onReportOrBlock = { onReportOrBlock(activeMatch.matchedMember) }
                )
            } else {
                ConversationsList(
                    matches = matches,
                    selectedMatchId = null,
                    isPreviewMode = state.isPreviewMode,
                    onSelectMatch = onOpenChat
                )
            }
        }
    }
}

@Composable
private fun ConversationsList(
    matches: List<MatchRecord>,
    selectedMatchId: String?,
    isPreviewMode: Boolean,
    onSelectMatch: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        if (isPreviewMode) {
            Surface(
                color = GoldSoftContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Info,
                        contentDescription = null,
                        tint = GoldDeep,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Preview messaging — live delivery activates once Supabase is connected.",
                        style = MaterialTheme.typography.bodySmall,
                        color = NavyDeep
                    )
                }
            }
        }

        if (matches.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.ChatBubbleOutline,
                        contentDescription = null,
                        tint = GoldRoyal,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No Conversations Yet",
                        style = MaterialTheme.typography.headlineSmall,
                        color = NavyDeep,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Once you match with another Christian single, your private chat will appear here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondarySlate,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(matches, key = { it.id }) { match ->
                    val isSelected = match.id == selectedMatchId
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectMatch(match.id) }
                            .testTag("conversation_item_${match.id}"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) GoldSoftContainer else PureWhite
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) GoldRoyal else MaterialTheme.colorScheme.outline
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ProfileAvatar(
                                profile = match.matchedMember,
                                size = 56.dp,
                                showGoldRing = match.unreadCount > 0
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = match.matchedMember.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = NavyDeep,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = match.lastMessageTime ?: "",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (match.unreadCount > 0) GoldDeep else TextSecondarySlate
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = match.lastMessagePreview ?: "Start a conversation",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondarySlate,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (match.unreadCount > 0) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Badge(
                                            containerColor = GoldRoyal,
                                            contentColor = NavyDeep
                                        ) {
                                            Text(
                                                text = match.unreadCount.toString(),
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatConversationPane(
    match: MatchRecord,
    messages: List<ChatMessage>,
    isPreviewMode: Boolean,
    showBackButton: Boolean,
    onBack: () -> Unit,
    onSendMessage: (String) -> Unit,
    onOpenProfile: () -> Unit,
    onReportOrBlock: () -> Unit
) {
    var draftMessage by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IvoryBackground)
            .imePadding()
    ) {
        // Chat Header
        Surface(
            color = PureWhite,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (showBackButton) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("chat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to conversations",
                            tint = NavyDeep
                        )
                    }
                }
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(onClick = onOpenProfile)
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ProfileAvatar(profile = match.matchedMember, size = 42.dp, showGoldRing = true)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = match.matchedMember.fullName,
                            style = MaterialTheme.typography.titleMedium,
                            color = NavyDeep,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${match.matchedMember.denomination} • ${match.matchedMember.location}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconButton(
                    onClick = onReportOrBlock,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("chat_safety_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = "Block or report member",
                        tint = NavyDeep
                    )
                }
            }
        }

        if (isPreviewMode) {
            Surface(
                color = GoldSoftContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Preview Chat — messages stay local until Supabase is connected",
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldDeep,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 6.dp, horizontal = 12.dp)
                )
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                MessageBubble(message = msg)
            }
        }

        HorizontalDivider()
        Surface(color = PureWhite) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = draftMessage,
                    onValueChange = { draftMessage = it },
                    placeholder = { Text("Write an encouraging message...") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_message_input"),
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 4
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = CircleShape,
                    color = if (draftMessage.isNotBlank()) NavyDeep else MaterialTheme.colorScheme.outline,
                    modifier = Modifier
                        .size(48.dp)
                        .clickable(enabled = draftMessage.isNotBlank()) {
                            onSendMessage(draftMessage)
                            draftMessage = ""
                        }
                        .testTag("chat_send_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send message",
                            tint = if (draftMessage.isNotBlank()) GoldBright else PureWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val alignment = if (message.isFromCurrentUser) Alignment.CenterEnd else Alignment.CenterStart
    val bubbleColor = if (message.isFromCurrentUser) NavyDeep else PureWhite
    val textColor = if (message.isFromCurrentUser) PureWhite else NavyDeep
    val timestampColor = if (message.isFromCurrentUser) GoldBright.copy(alpha = 0.85f) else TextSecondarySlate

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = alignment
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 290.dp),
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (message.isFromCurrentUser) 18.dp else 4.dp,
                bottomEnd = if (message.isFromCurrentUser) 4.dp else 18.dp
            ),
            color = bubbleColor,
            border = if (!message.isFromCurrentUser) BorderStroke(1.dp, MaterialTheme.colorScheme.outline) else null,
            shadowElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = textColor
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.timestampLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = timestampColor,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}
