package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppNotification
import com.example.data.model.ChatMessage
import com.example.data.model.ConnectionRequest
import com.example.data.model.DiscoverFilters
import com.example.data.model.Gender
import com.example.data.model.MatchRecord
import com.example.data.model.MemberProfile
import com.example.data.model.NotificationType
import com.example.data.model.PrivacySettings
import com.example.data.model.RelationshipIntent
import com.example.data.model.ReportReason
import com.example.data.model.RequestStatus
import com.example.data.model.SafetyReportRecord
import com.example.data.model.SampleData
import com.example.data.remote.SupabaseConfig
import com.example.data.remote.SupabaseRepository
import com.example.data.remote.SupabaseResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class DashboardTab(val label: String) {
    HOME("Home"),
    DISCOVER("Discover"),
    MATCHES("Matches"),
    MESSAGES("Messages"),
    PROFILE("Profile")
}

data class CovenantUiState(
    val isSupabaseConfigured: Boolean = SupabaseConfig.isConfigured,
    val isPreviewMode: Boolean = false,
    val isAuthenticatedLive: Boolean = false,
    val pendingVerificationEmail: String = "",
    val isAuthLoading: Boolean = false,
    val authFeedbackMessage: String? = null,
    val authIsError: Boolean = false,

    val activeTab: DashboardTab = DashboardTab.HOME,
    val currentUser: MemberProfile = SampleData.defaultCurrentUser,
    val allDiscoverProfiles: List<MemberProfile> = SampleData.sampleDiscoverProfiles,
    val passedProfileIds: Set<String> = emptySet(),
    val filters: DiscoverFilters = DiscoverFilters(),

    val matches: List<MatchRecord> = SampleData.sampleMatches,
    val connectionRequests: List<ConnectionRequest> = SampleData.sampleRequests,
    val messagesByMatchId: Map<String, List<ChatMessage>> = SampleData.sampleMessages,
    val activeChatMatchId: String? = null,

    val notifications: List<AppNotification> = SampleData.sampleNotifications,
    val blockedUserIds: Set<String> = emptySet(),
    val safetyReports: List<SafetyReportRecord> = emptyList(),
    val privacySettings: PrivacySettings = PrivacySettings(),

    val celebratedMatch: MatchRecord? = null,
    val selectedProfileForDetail: MemberProfile? = null,
    val statusBannerMessage: String? = null
) {
    val unreadNotificationCount: Int
        get() = notifications.count { !it.isRead }

    val unreadMessageCount: Int
        get() = matches.filterNot { it.matchedMember.id in blockedUserIds }.sumOf { it.unreadCount }

    val incomingRequests: List<ConnectionRequest>
        get() = connectionRequests.filter {
            it.isIncoming && it.status == RequestStatus.PENDING && it.senderProfile.id !in blockedUserIds
        }

    val outgoingRequests: List<ConnectionRequest>
        get() = connectionRequests.filter {
            !it.isIncoming && it.status == RequestStatus.PENDING && it.senderProfile.id !in blockedUserIds
        }

    val visibleMatches: List<MatchRecord>
        get() = matches.filterNot { it.matchedMember.id in blockedUserIds }

    val filteredDiscoverProfiles: List<MemberProfile>
        get() = allDiscoverProfiles.filter { profile ->
            profile.id !in blockedUserIds &&
                profile.id !in passedProfileIds &&
                profile.id != currentUser.id &&
                profile.age in filters.minAge..filters.maxAge &&
                (filters.locationQuery.isBlank() ||
                    profile.location.contains(filters.locationQuery.trim(), ignoreCase = true)) &&
                (filters.selectedDenomination == null ||
                    profile.denomination.equals(filters.selectedDenomination, ignoreCase = true))
        }

    val blockedMembers: List<MemberProfile>
        get() = allDiscoverProfiles.filter { it.id in blockedUserIds }
}

class CovenantViewModel(
    private val supabaseRepository: SupabaseRepository = SupabaseRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(CovenantUiState())
    val uiState: StateFlow<CovenantUiState> = _uiState.asStateFlow()

    fun clearAuthFeedback() {
        _uiState.update { it.copy(authFeedbackMessage = null, authIsError = false) }
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun enterPreviewMode(onEntered: () -> Unit) {
        _uiState.update {
            it.copy(
                isPreviewMode = true,
                isAuthenticatedLive = false,
                authFeedbackMessage = null,
                authIsError = false,
                activeTab = DashboardTab.HOME
            )
        }
        onEntered()
    }

    fun signIn(email: String, password: String, onSuccess: () -> Unit) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank() || !cleanEmail.contains("@")) {
            _uiState.update {
                it.copy(authFeedbackMessage = "Please enter a valid email address.", authIsError = true)
            }
            return
        }
        if (password.length < 6) {
            _uiState.update {
                it.copy(authFeedbackMessage = "Password must be at least 6 characters.", authIsError = true)
            }
            return
        }

        if (!SupabaseConfig.isConfigured) {
            _uiState.update {
                it.copy(
                    authFeedbackMessage = "Supabase authentication is not connected yet. Configure SUPABASE_URL and SUPABASE_ANON_KEY in AI Studio Secrets to sign in live, or tap 'Explore UI Preview' to inspect the app with sample profiles.",
                    authIsError = true
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isAuthLoading = true, authFeedbackMessage = null, authIsError = false) }
            when (val result = supabaseRepository.signIn(cleanEmail, password)) {
                is SupabaseResult.Success -> {
                    val userEmail = result.data.user?.email ?: cleanEmail
                    val verified = result.data.user?.emailConfirmedAt != null
                    _uiState.update {
                        it.copy(
                            isAuthLoading = false,
                            isAuthenticatedLive = true,
                            isPreviewMode = false,
                            currentUser = it.currentUser.copy(
                                id = result.data.user?.id ?: it.currentUser.id,
                                email = userEmail,
                                emailVerified = verified,
                                isSampleProfile = false
                            )
                        )
                    }
                    loadLiveProfilesIfPossible()
                    onSuccess()
                }
                is SupabaseResult.NotConfigured -> {
                    _uiState.update {
                        it.copy(
                            isAuthLoading = false,
                            authFeedbackMessage = "Supabase credentials are not configured yet.",
                            authIsError = true
                        )
                    }
                }
                is SupabaseResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isAuthLoading = false,
                            authFeedbackMessage = result.message,
                            authIsError = true
                        )
                    }
                }
            }
        }
    }

    fun register(
        fullName: String,
        email: String,
        password: String,
        dateOfBirth: String,
        age: Int,
        gender: Gender,
        location: String,
        denomination: String,
        acceptedCovenant: Boolean,
        onVerificationNeeded: () -> Unit
    ) {
        val cleanName = fullName.trim()
        val cleanEmail = email.trim()
        val cleanLocation = location.trim()

        val validationError = when {
            cleanName.length < 2 -> "Please enter your full name."
            cleanEmail.isBlank() || !cleanEmail.contains("@") -> "Please enter a valid email address."
            password.length < 8 -> "Please choose a password of at least 8 characters."
            age < 18 -> "Members must be at least 18 years old to join Covenant Connect."
            cleanLocation.isBlank() -> "Please enter your city and state or region."
            !acceptedCovenant -> "Please agree to the Christ-Centered Community Guidelines & Privacy Policy."
            else -> null
        }

        if (validationError != null) {
            _uiState.update { it.copy(authFeedbackMessage = validationError, authIsError = true) }
            return
        }

        if (!SupabaseConfig.isConfigured) {
            _uiState.update {
                it.copy(
                    authFeedbackMessage = "Supabase registration & email verification require SUPABASE_URL and SUPABASE_ANON_KEY in AI Studio Secrets. No fake account was created. You can use 'Explore UI Preview' to review the Member Dashboard.",
                    authIsError = true
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isAuthLoading = true, authFeedbackMessage = null, authIsError = false) }
            when (
                val result = supabaseRepository.signUp(
                    fullName = cleanName,
                    email = cleanEmail,
                    password = password,
                    dateOfBirth = dateOfBirth,
                    age = age,
                    gender = gender,
                    location = cleanLocation,
                    denomination = denomination
                )
            ) {
                is SupabaseResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isAuthLoading = false,
                            pendingVerificationEmail = cleanEmail,
                            currentUser = it.currentUser.copy(
                                id = result.data.user?.id ?: it.currentUser.id,
                                fullName = cleanName,
                                email = cleanEmail,
                                dateOfBirth = dateOfBirth,
                                age = age,
                                gender = gender,
                                location = cleanLocation,
                                denomination = denomination,
                                emailVerified = result.data.user?.emailConfirmedAt != null,
                                isSampleProfile = false
                            ),
                            authFeedbackMessage = "Verification link sent to $cleanEmail.",
                            authIsError = false
                        )
                    }
                    onVerificationNeeded()
                }
                is SupabaseResult.NotConfigured -> {
                    _uiState.update {
                        it.copy(
                            isAuthLoading = false,
                            authFeedbackMessage = "Supabase credentials are not configured.",
                            authIsError = true
                        )
                    }
                }
                is SupabaseResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isAuthLoading = false,
                            authFeedbackMessage = result.message,
                            authIsError = true
                        )
                    }
                }
            }
        }
    }

    fun resendVerificationEmail() {
        val email = _uiState.value.pendingVerificationEmail
        if (email.isBlank()) return
        if (!SupabaseConfig.isConfigured) {
            _uiState.update {
                it.copy(
                    authFeedbackMessage = "Connect Supabase credentials to send live verification emails.",
                    authIsError = true
                )
            }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isAuthLoading = true) }
            when (val result = supabaseRepository.resendVerificationEmail(email)) {
                is SupabaseResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isAuthLoading = false,
                            authFeedbackMessage = "Verification email resent to $email.",
                            authIsError = false
                        )
                    }
                }
                is SupabaseResult.Error -> {
                    _uiState.update {
                        it.copy(isAuthLoading = false, authFeedbackMessage = result.message, authIsError = true)
                    }
                }
                SupabaseResult.NotConfigured -> {
                    _uiState.update {
                        it.copy(
                            isAuthLoading = false,
                            authFeedbackMessage = "Supabase is not configured.",
                            authIsError = true
                        )
                    }
                }
            }
        }
    }

    private fun loadLiveProfilesIfPossible() {
        if (!supabaseRepository.hasLiveSession()) return
        viewModelScope.launch {
            when (val result = supabaseRepository.fetchLiveProfiles()) {
                is SupabaseResult.Success -> {
                    if (result.data.isNotEmpty()) {
                        _uiState.update { it.copy(allDiscoverProfiles = result.data) }
                    }
                }
                else -> Unit
            }
        }
    }

    fun selectTab(tab: DashboardTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun updateFilters(filters: DiscoverFilters) {
        _uiState.update { it.copy(filters = filters) }
    }

    fun resetFilters() {
        _uiState.update { it.copy(filters = DiscoverFilters()) }
    }

    fun openProfileDetail(profile: MemberProfile?) {
        _uiState.update { it.copy(selectedProfileForDetail = profile) }
    }

    fun passProfile(profile: MemberProfile) {
        _uiState.update {
            it.copy(
                passedProfileIds = it.passedProfileIds + profile.id,
                selectedProfileForDetail = null,
                statusBannerMessage = "Skipped ${profile.fullName}."
            )
        }
    }

    fun expressInterest(profile: MemberProfile, note: String = "") {
        val state = _uiState.value
        val alreadyRequested = state.connectionRequests.any {
            !it.isIncoming && it.receiverId == profile.id
        }
        val alreadyMatched = state.matches.any { it.matchedMember.id == profile.id }
        if (alreadyMatched) {
            _uiState.update {
                it.copy(
                    selectedProfileForDetail = null,
                    statusBannerMessage = "You are already matched with ${profile.fullName}!"
                )
            }
            return
        }
        if (alreadyRequested) {
            _uiState.update {
                it.copy(
                    selectedProfileForDetail = null,
                    statusBannerMessage = "Connection request already sent to ${profile.fullName}."
                )
            }
            return
        }

        // Check if this member already sent us an incoming request -> Mutual Match!
        val incomingFromMember = state.connectionRequests.firstOrNull {
            it.isIncoming && it.senderProfile.id == profile.id && it.status == RequestStatus.PENDING
        }

        if (incomingFromMember != null) {
            acceptConnectionRequest(incomingFromMember)
            return
        }

        val greetingNote = note.trim().ifBlank {
            "Peace and grace! I would love to connect and get to know you better."
        }
        val newRequest = ConnectionRequest(
            id = "req_${UUID.randomUUID().toString().take(8)}",
            senderId = state.currentUser.id,
            receiverId = profile.id,
            senderProfile = profile,
            status = RequestStatus.PENDING,
            note = greetingNote,
            createdAtLabel = "Just now",
            isIncoming = false
        )

        if (state.isAuthenticatedLive) {
            viewModelScope.launch {
                supabaseRepository.sendLiveConnectionRequest(state.currentUser.id, profile.id, greetingNote)
            }
        }

        _uiState.update {
            it.copy(
                connectionRequests = listOf(newRequest) + it.connectionRequests,
                passedProfileIds = it.passedProfileIds + profile.id,
                selectedProfileForDetail = null,
                statusBannerMessage = if (it.isPreviewMode) {
                    "Preview: Interest sent to ${profile.fullName} (connect Supabase to sync live)."
                } else {
                    "Connection request sent to ${profile.fullName}."
                }
            )
        }
    }

    fun acceptConnectionRequest(request: ConnectionRequest) {
        val newMatchId = "match_${UUID.randomUUID().toString().take(8)}"
        val newMatch = MatchRecord(
            id = newMatchId,
            matchedMember = request.senderProfile,
            matchedAtLabel = "Matched just now",
            lastMessagePreview = "You are now connected! Say hello with grace.",
            lastMessageTime = "Now",
            unreadCount = 0
        )
        val matchNotification = AppNotification(
            id = "notif_${UUID.randomUUID().toString().take(8)}",
            type = NotificationType.MATCH,
            title = "New Covenant Match!",
            body = "You and ${request.senderProfile.fullName} are now matched.",
            timestampLabel = "Just now",
            isRead = false,
            relatedMemberId = request.senderProfile.id,
            relatedMatchId = newMatchId
        )

        _uiState.update { state ->
            state.copy(
                connectionRequests = state.connectionRequests.map {
                    if (it.id == request.id) it.copy(status = RequestStatus.ACCEPTED) else it
                },
                matches = listOf(newMatch) + state.matches.filterNot { it.matchedMember.id == request.senderProfile.id },
                notifications = listOf(matchNotification) + state.notifications,
                celebratedMatch = newMatch,
                selectedProfileForDetail = null
            )
        }
    }

    fun declineConnectionRequest(request: ConnectionRequest) {
        _uiState.update { state ->
            state.copy(
                connectionRequests = state.connectionRequests.map {
                    if (it.id == request.id) it.copy(status = RequestStatus.DECLINED) else it
                },
                statusBannerMessage = "Request from ${request.senderProfile.fullName} declined."
            )
        }
    }

    fun dismissMatchCelebration() {
        _uiState.update { it.copy(celebratedMatch = null) }
    }

    fun openChat(matchId: String) {
        _uiState.update { state ->
            state.copy(
                activeTab = DashboardTab.MESSAGES,
                activeChatMatchId = matchId,
                celebratedMatch = null,
                matches = state.matches.map {
                    if (it.id == matchId) it.copy(unreadCount = 0) else it
                }
            )
        }
    }

    fun closeChat() {
        _uiState.update { it.copy(activeChatMatchId = null) }
    }

    fun sendChatMessage(matchId: String, text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        val state = _uiState.value
        val timestamp = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        val newMsg = ChatMessage(
            id = "msg_${UUID.randomUUID().toString().take(8)}",
            matchId = matchId,
            senderId = state.currentUser.id,
            content = clean,
            timestampLabel = timestamp,
            isFromCurrentUser = true,
            isPreviewOnly = !state.isAuthenticatedLive
        )

        if (state.isAuthenticatedLive) {
            viewModelScope.launch {
                supabaseRepository.sendLiveMessage(matchId, state.currentUser.id, clean)
            }
        }

        _uiState.update { current ->
            val updatedList = current.messagesByMatchId[matchId].orEmpty() + newMsg
            current.copy(
                messagesByMatchId = current.messagesByMatchId + (matchId to updatedList),
                matches = current.matches.map { match ->
                    if (match.id == matchId) {
                        match.copy(lastMessagePreview = clean, lastMessageTime = timestamp)
                    } else match
                }
            )
        }
    }

    fun markAllNotificationsRead() {
        _uiState.update { state ->
            state.copy(notifications = state.notifications.map { it.copy(isRead = true) })
        }
    }

    fun handleNotificationTap(notification: AppNotification) {
        _uiState.update { state ->
            state.copy(
                notifications = state.notifications.map {
                    if (it.id == notification.id) it.copy(isRead = true) else it
                }
            )
        }
        when {
            notification.relatedMatchId != null -> openChat(notification.relatedMatchId)
            notification.type == NotificationType.LIKE -> selectTab(DashboardTab.MATCHES)
            else -> selectTab(DashboardTab.DISCOVER)
        }
    }

    fun updateCurrentUserProfile(updated: MemberProfile) {
        _uiState.update {
            it.copy(
                currentUser = updated,
                statusBannerMessage = if (it.isPreviewMode) {
                    "Preview profile updated locally (connect Supabase to save to profiles table)."
                } else {
                    "Profile updated."
                }
            )
        }
    }

    fun updatePickedPhoto(uriString: String) {
        _uiState.update {
            it.copy(
                currentUser = it.currentUser.copy(localPickedPhotoUri = uriString),
                statusBannerMessage = "Profile photograph updated."
            )
        }
    }

    fun blockUser(member: MemberProfile) {
        _uiState.update { state ->
            state.copy(
                blockedUserIds = state.blockedUserIds + member.id,
                selectedProfileForDetail = null,
                activeChatMatchId = if (state.matches.any { it.id == state.activeChatMatchId && it.matchedMember.id == member.id }) {
                    null
                } else state.activeChatMatchId,
                statusBannerMessage = "${member.fullName} has been blocked. They can no longer view your profile or message you."
            )
        }
    }

    fun unblockUser(userId: String) {
        _uiState.update { state ->
            state.copy(
                blockedUserIds = state.blockedUserIds - userId,
                statusBannerMessage = "Member unblocked."
            )
        }
    }

    fun reportUser(
        member: MemberProfile,
        reason: ReportReason,
        details: String,
        alsoBlock: Boolean
    ) {
        val timestamp = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date())
        val report = SafetyReportRecord(
            id = "rep_${UUID.randomUUID().toString().take(8)}",
            reportedUserId = member.id,
            reportedUserName = member.fullName,
            reason = reason,
            details = details.trim(),
            timestampLabel = timestamp
        )
        _uiState.update { state ->
            state.copy(
                safetyReports = listOf(report) + state.safetyReports,
                blockedUserIds = if (alsoBlock) state.blockedUserIds + member.id else state.blockedUserIds,
                selectedProfileForDetail = null,
                statusBannerMessage = "Safety report submitted for ${member.fullName}. Thank you for helping keep Covenant Connect safe."
            )
        }
    }

    fun updatePrivacySettings(settings: PrivacySettings) {
        _uiState.update {
            it.copy(
                privacySettings = settings,
                statusBannerMessage = "Privacy preferences updated."
            )
        }
    }

    fun signOut(onSignedOut: () -> Unit) {
        supabaseRepository.signOut()
        _uiState.update {
            CovenantUiState(
                isSupabaseConfigured = SupabaseConfig.isConfigured
            )
        }
        onSignedOut()
    }
}
