package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.Denomination
import com.example.data.model.DiscoverFilters
import com.example.data.model.MemberProfile
import com.example.ui.components.FaithTagPill
import com.example.ui.components.ProfileAvatar
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GoldSoftContainer
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.viewmodel.CovenantUiState
import kotlin.math.roundToInt

@Composable
fun DiscoverTab(
    state: CovenantUiState,
    onOpenFilters: () -> Unit,
    onResetFilters: () -> Unit,
    onOpenProfileDetail: (MemberProfile) -> Unit,
    onExpressInterest: (MemberProfile) -> Unit,
    onPass: (MemberProfile) -> Unit
) {
    val profiles = state.filteredDiscoverProfiles
    val activeFilterCount = listOfNotNull(
        if (state.filters.minAge != 21 || state.filters.maxAge != 45) "age" else null,
        if (state.filters.locationQuery.isNotBlank()) "loc" else null,
        state.filters.selectedDenomination
    ).size

    Column(modifier = Modifier.fillMaxSize()) {
        // Filter Bar
        Surface(
            color = PureWhite,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (state.isPreviewMode) "Discover Singles (Preview)" else "Discover Singles",
                        style = MaterialTheme.typography.titleMedium,
                        color = NavyDeep
                    )
                    Text(
                        text = "Ages ${state.filters.minAge}–${state.filters.maxAge}" +
                            (state.filters.selectedDenomination?.let { " • $it" } ?: " • All Denominations") +
                            (if (state.filters.locationQuery.isNotBlank()) " • ${state.filters.locationQuery}" else ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(
                    onClick = onOpenFilters,
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, GoldRoyal),
                    modifier = Modifier.testTag("discover_filters_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Tune,
                        contentDescription = "Filter profiles",
                        tint = NavyDeep,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (activeFilterCount > 0) "Filters ($activeFilterCount)" else "Filters",
                        color = NavyDeep
                    )
                }
            }
        }

        if (profiles.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.Explore,
                        contentDescription = null,
                        tint = GoldRoyal,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "No More Profiles Right Now",
                        style = MaterialTheme.typography.headlineSmall,
                        color = NavyDeep,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Try widening your age range, clearing location text, or resetting your denomination filter.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondarySlate,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onResetFilters,
                        colors = ButtonDefaults.buttonColors(containerColor = NavyDeep),
                        modifier = Modifier.testTag("discover_reset_filters_button")
                    ) {
                        Text("Reset Filters")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(profiles, key = { it.id }) { member ->
                    DiscoverProfileCard(
                        member = member,
                        onViewFullProfile = { onOpenProfileDetail(member) },
                        onExpressInterest = { onExpressInterest(member) },
                        onPass = { onPass(member) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DiscoverProfileCard(
    member: MemberProfile,
    onViewFullProfile: () -> Unit,
    onExpressInterest: () -> Unit,
    onPass: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onViewFullProfile)
            .testTag("discover_card_${member.id}"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(profile = member, size = 76.dp, showGoldRing = true)
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${member.fullName}, ${member.age}",
                            style = MaterialTheme.typography.titleLarge,
                            color = NavyDeep
                        )
                        if (member.emailVerified) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Filled.Verified,
                                contentDescription = "Verified member",
                                tint = GoldRoyal,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = null,
                            tint = TextSecondarySlate,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = member.location,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = NavyDeep
                        ) {
                            Text(
                                text = member.denomination,
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldBright,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        if (member.isSampleProfile) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = GoldSoftContainer
                            ) {
                                Text(
                                    text = "Sample",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldDeep,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Work,
                    contentDescription = null,
                    tint = NavyDeep,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = member.occupation,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = NavyDeep
                )
                Spacer(modifier = Modifier.width(12.dp))
                Icon(
                    imageVector = Icons.Filled.School,
                    contentDescription = null,
                    tint = TextSecondarySlate,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = member.education,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = member.relationshipIntent.label,
                style = MaterialTheme.typography.labelMedium,
                color = GoldDeep
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = member.bio,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondarySlate,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            if (member.faithAndValues.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    member.faithAndValues.take(3).forEach { tag ->
                        FaithTagPill(label = tag)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onPass,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("discover_pass_${member.id}"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Pass")
                }
                Button(
                    onClick = onExpressInterest,
                    modifier = Modifier
                        .weight(1.5f)
                        .height(48.dp)
                        .testTag("discover_interest_${member.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldRoyal,
                        contentColor = NavyDeep
                    )
                ) {
                    Icon(Icons.Filled.Favorite, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Express Interest", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DiscoverFiltersSheet(
    currentFilters: DiscoverFilters,
    onDismiss: () -> Unit,
    onApply: (DiscoverFilters) -> Unit,
    onReset: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var ageRange by remember {
        mutableStateOf(currentFilters.minAge.toFloat()..currentFilters.maxAge.toFloat())
    }
    var locationQuery by remember { mutableStateOf(currentFilters.locationQuery) }
    var selectedDenom by remember { mutableStateOf(currentFilters.selectedDenomination) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = PureWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Filter Christian Singles",
                    style = MaterialTheme.typography.headlineSmall,
                    color = NavyDeep
                )
                TextButton(onClick = {
                    onReset()
                    onDismiss()
                }) {
                    Text("Reset", color = GoldDeep, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Age Range: ${ageRange.start.roundToInt()} – ${ageRange.endInclusive.roundToInt()} years",
                style = MaterialTheme.typography.titleSmall,
                color = NavyDeep
            )
            RangeSlider(
                value = ageRange,
                onValueChange = { ageRange = it },
                valueRange = 18f..65f,
                colors = SliderDefaults.colors(
                    thumbColor = GoldRoyal,
                    activeTrackColor = NavyDeep
                )
            )

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = locationQuery,
                onValueChange = { locationQuery = it },
                label = { Text("Location (City or State)") },
                placeholder = { Text("e.g., TX, Dallas, Atlanta") },
                leadingIcon = { Icon(Icons.Filled.LocationOn, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("filter_location_input")
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Church Denomination",
                style = MaterialTheme.typography.titleSmall,
                color = NavyDeep
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedDenom == null,
                    onClick = { selectedDenom = null },
                    label = { Text("All") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NavyDeep,
                        selectedLabelColor = GoldBright
                    )
                )
                Denomination.entries.forEach { denom ->
                    FilterChip(
                        selected = selectedDenom == denom.label,
                        onClick = {
                            selectedDenom = if (selectedDenom == denom.label) null else denom.label
                        },
                        label = { Text(denom.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NavyDeep,
                            selectedLabelColor = GoldBright
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))
            Button(
                onClick = {
                    onApply(
                        DiscoverFilters(
                            minAge = ageRange.start.roundToInt(),
                            maxAge = ageRange.endInclusive.roundToInt(),
                            locationQuery = locationQuery,
                            selectedDenomination = selectedDenom
                        )
                    )
                    onDismiss()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("apply_filters_button"),
                colors = ButtonDefaults.buttonColors(containerColor = NavyDeep)
            ) {
                Text("Apply Filters", fontWeight = FontWeight.Bold)
            }
        }
    }
}
