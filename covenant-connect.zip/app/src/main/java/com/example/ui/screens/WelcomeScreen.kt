package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.remote.SupabaseConfig
import com.example.ui.components.CovenantCrestLogo
import com.example.ui.components.SupabaseStatusBanner
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GoldSoftContainer
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyMedium
import com.example.ui.theme.NavyRich
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondarySlate

@Composable
fun WelcomeScreen(
    isSupabaseConfigured: Boolean,
    onNavigateToRegister: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onExplorePreview: () -> Unit
) {
    var showSupabaseInfoDialog by remember { mutableStateOf(false) }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        containerColor = NavyDeep
    ) { _ ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(NavyDeep, NavyRich, NavyMedium)
                    )
                )
                .drawBehind {
                    val archStroke = Stroke(width = 1.5.dp.toPx())
                    val goldFaint = GoldRoyal.copy(alpha = 0.16f)
                    val goldSubtle = GoldBright.copy(alpha = 0.08f)

                    // Subtle golden radial aura behind crest
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(GoldRoyal.copy(alpha = 0.22f), NavyDeep.copy(alpha = 0f)),
                            center = Offset(size.width / 2f, size.height * 0.16f),
                            radius = size.width * 0.65f
                        ),
                        radius = size.width * 0.65f,
                        center = Offset(size.width / 2f, size.height * 0.16f)
                    )

                    // Architectural sacred arch filigree
                    val outerMargin = size.width * 0.08f
                    drawArc(
                        color = goldFaint,
                        startAngle = 180f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = Offset(outerMargin, size.height * 0.05f),
                        size = Size(size.width - outerMargin * 2, size.height * 0.34f),
                        style = archStroke
                    )
                    val innerMargin = size.width * 0.14f
                    drawArc(
                        color = goldSubtle,
                        startAngle = 180f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = Offset(innerMargin, size.height * 0.075f),
                        size = Size(size.width - innerMargin * 2, size.height * 0.29f),
                        style = archStroke
                    )
                }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.widthIn(max = 560.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(modifier = Modifier.height(10.dp))
                        CovenantCrestLogo(size = 86.dp)
                        Spacer(modifier = Modifier.height(18.dp))

                        Text(
                            text = stringResource(R.string.brand_title_upper),
                            style = MaterialTheme.typography.displaySmall.copy(
                                letterSpacing = 2.5.sp
                            ),
                            color = PureWhite,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stringResource(R.string.brand_tagline),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontStyle = FontStyle.Italic
                            ),
                            color = GoldBright,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(22.dp))

                        // Crisp White & Gold Mission Card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(22.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = GoldSoftContainer
                                ) {
                                    Text(
                                        text = "CHRISTIAN COURTSHIP & MATCHMAKING",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GoldDeep,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = stringResource(R.string.welcome_mission_title),
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = NavyDeep
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = stringResource(R.string.welcome_mission_body),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondarySlate
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                                Spacer(modifier = Modifier.height(14.dp))

                                MissionPillarRow(
                                    icon = Icons.Filled.Favorite,
                                    title = "Intentional & Marriage-Minded",
                                    subtitle = "Connect with believers who share your faith, denomination values, and life vision."
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                MissionPillarRow(
                                    icon = Icons.Filled.VerifiedUser,
                                    title = "Verified Christian Community",
                                    subtitle = "Email-verified accounts and sincere faith testimonies build trust from day one."
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                MissionPillarRow(
                                    icon = Icons.Filled.Shield,
                                    title = "Safety, Privacy & Honor",
                                    subtitle = "Private details stay protected, with instant block and report accountability."
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        SupabaseStatusBanner(
                            isSupabaseConfigured = isSupabaseConfigured,
                            isAuthenticatedLive = false,
                            onLearnMoreClick = { showSupabaseInfoDialog = true }
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = onNavigateToRegister,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("welcome_sign_up_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldRoyal,
                                contentColor = NavyDeep
                            )
                        ) {
                            Text(
                                text = stringResource(R.string.action_sign_up),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = onNavigateToLogin,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("welcome_login_button"),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.5.dp, GoldBright),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite)
                        ) {
                            Text(
                                text = stringResource(R.string.action_login),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        TextButton(
                            onClick = onExplorePreview,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("welcome_preview_button")
                        ) {
                            Text(
                                text = "Explore UI Preview with Sample Profiles",
                                style = MaterialTheme.typography.labelLarge,
                                color = GoldBright
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSupabaseInfoDialog) {
        AlertDialog(
            onDismissRequest = { showSupabaseInfoDialog = false },
            title = { Text("Supabase Backend Readiness") },
            text = {
                Column {
                    Text(
                        text = if (isSupabaseConfigured) {
                            "Supabase credentials are present. Live Auth and PostgREST calls target your project tables:"
                        } else {
                            "To connect your existing Supabase project without placing keys in source code, add SUPABASE_URL and SUPABASE_ANON_KEY in AI Studio Secrets. The client is already mapped to your tables:"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SupabaseConfig.expectedTables.forEach { table ->
                        Text(
                            text = "• ${table.tableName} — ${table.description}",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSupabaseInfoDialog = false }) {
                    Text("Got It")
                }
            }
        )
    }
}

@Composable
private fun MissionPillarRow(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Row(verticalAlignment = Alignment.Top) {
        Surface(
            shape = CircleShape,
            color = NavyDeep,
            modifier = Modifier.size(34.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = GoldBright,
                    modifier = Modifier.size(17.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = NavyDeep
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondarySlate
            )
        }
    }
}
