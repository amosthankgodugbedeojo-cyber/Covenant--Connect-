package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Deep Navy Palette
val NavyDeep = Color(0xFF0B1D3A)
val NavyRich = Color(0xFF122B52)
val NavyMedium = Color(0xFF1D3E73)
val NavyMuted = Color(0xFF315080)
val NavySoftContainer = Color(0xFFE7EEF8)

// Elegant Gold Palette
val GoldRoyal = Color(0xFFC8A24B)
val GoldBright = Color(0xFFDFBE6F)
val GoldDeep = Color(0xFF967322)
val GoldSoftContainer = Color(0xFFF9F2DF)
val GoldBorder = Color(0xFFE2C98A)

// Crisp White & Warm Neutral Palette
val PureWhite = Color(0xFFFFFFFF)
val IvoryBackground = Color(0xFFFAFBFD)
val SoftSlateSurface = Color(0xFFF2F5FA)
val OutlineMist = Color(0xFFD5DCE8)
val TextPrimaryNavy = Color(0xFF0E1B30)
val TextSecondarySlate = Color(0xFF4F5D75)

// Semantic Status Colors
val VerifiedEmerald = Color(0xFF1A7A52)
val VerifiedEmeraldContainer = Color(0xFFE3F5EC)
val AlertCrimson = Color(0xFFBA1A1A)
val AlertCrimsonContainer = Color(0xFFFFDAD6)

// Dark Mode Surfaces
val DarkNavyBackground = Color(0xFF071224)
val DarkNavySurface = Color(0xFF0E1E38)
val DarkNavySurfaceHigh = Color(0xFF162B4D)
