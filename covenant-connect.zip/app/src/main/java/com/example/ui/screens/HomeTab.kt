package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.MemberProfile
import com.example.ui.components.ProfileAvatar
import com.example.ui.components.SupabaseStatusBanner
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GoldSoftContainer
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyMedium
import com.example.ui.theme.NavyRich
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.viewmodel.CovenantUiState
import com.example.ui.viewmodel.DashboardTab

@Composable
fun HomeTab(
    state: CovenantUiState,
    onSelectTab: (DashboardTab) -> Unit,
    onOpenProfileDetail: (MemberProfile) -> Unit,
    onOpenSafetyCenter: () -> Unit,
    onOpenSupabaseInfo: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SupabaseStatusBanner(
                isSupabaseConfigured = state.isSupabaseConfigured,
                isAuthenticatedLive = state.isAuthenticatedLive,
                onLearnMoreClick = onOpenSupabaseInfo
            )
        }

        // Welcome Member Hero Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = NavyDeep)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(NavyDeep, NavyRich, NavyMedium)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ProfileAvatar(
                                profile = state.currentUser,
                                size = 54.dp,
                                showGoldRing = true
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Grace and peace,",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GoldBright
                                )
                                Text(
                                    text = state.currentUser.fullName,
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = PureWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${state.currentUser.denomination} • ${state.currentUser.location}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PureWhite.copy(alpha = 0.78f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = PureWhite.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, GoldRoyal.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.MenuBook,
                                    contentDescription = null,
                                    tint = GoldBright,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Daily Scripture Reflection",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = GoldBright
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "\"Above all, clothe yourselves with love, which binds us all together in perfect harmony.\" — Colossians 3:14",
                                        style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                                        color = PureWhite.copy(alpha = 0.92f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Quick Activity Stats
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickStatCard(
                    icon = Icons.Filled.AutoAwesome,
                    count = state.visibleMatches.size.toString(),
                    label = "Matches",
                    onClick = { onSelectTab(DashboardTab.MATCHES) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_stat_matches")
                )
                QuickStatCard(
                    icon = Icons.Filled.Favorite,
                    count = state.incomingRequests.size.toString(),
                    label = "Requests",
                    onClick = { onSelectTab(DashboardTab.MATCHES) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_stat_requests")
                )
                QuickStatCard(
                    icon = Icons.Filled.ChatBubble,
                    count = state.unreadMessageCount.toString(),
                    label = "Unread",
                    onClick = { onSelectTab(DashboardTab.MESSAGES) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_stat_messages")
                )
            }
        }

        // Featured Singles Carousel
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (state.isPreviewMode) "Sample Christian Singles" else "Faithful Singles Near You",
                        style = MaterialTheme.typography.headlineSmall,
                        color = NavyDeep
                    )
                    Text(
                        text = "Intentional believers open to godly courtship",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate
                    )
                }
                TextButton(
                    onClick = { onSelectTab(DashboardTab.DISCOVER) },
                    modifier = Modifier.testTag("home_see_all_discover")
                ) {
                    Text("Discover", color = GoldDeep, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = GoldDeep,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        item {
            val spotlight = state.filteredDiscoverProfiles.take(5)
            if (spotlight.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Explore,
                            contentDescription = null,
                            tint = GoldDeep,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No profiles match your current filters.",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { onSelectTab(DashboardTab.DISCOVER) },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyDeep)
                        ) {
                            Text("Adjust Discover Filters")
                        }
                    }
                }
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(spotlight, key = { it.id }) { member ->
                        FeaturedMemberCard(
                            member = member,
                            onClick = { onOpenProfileDetail(member) }
                        )
                    }
                }
            }
        }

        // Safety & Community Covenant Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenSafetyCenter),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, GoldRoyal.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = GoldSoftContainer,
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = GoldDeep
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Safety, Privacy & Community Covenant",
                            style = MaterialTheme.typography.titleSmall,
                            color = NavyDeep
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Manage privacy controls, blocked accounts, and Christ-honoring conduct guidelines.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate
                        )
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = GoldDeep
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickStatCard(
    icon: ImageVector,
    count: String,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = GoldRoyal,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = count,
                style = MaterialTheme.typography.headlineSmall,
                color = NavyDeep,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondarySlate
            )
        }
    }
}

@Composable
private fun FeaturedMemberCard(
    member: MemberProfile,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(210.dp)
            .clickable(onClick = onClick)
            .testTag("featured_card_${member.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(profile = member, size = 56.dp, showGoldRing = true)
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${member.fullName.substringBefore(" ")}, ${member.age}",
                        style = MaterialTheme.typography.titleMedium,
                        color = NavyDeep,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = null,
                            tint = TextSecondarySlate,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = member.location,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondarySlate,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                shape = RoundedCornerShape(50),
                color = NavyDeep
            ) {
                Text(
                    text = member.denomination,
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldBright,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = member.occupation,
                style = MaterialTheme.typography.labelMedium,
                color = GoldDeep,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = member.bio,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondarySlate,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
