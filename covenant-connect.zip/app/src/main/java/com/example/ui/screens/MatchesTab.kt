package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ConnectionRequest
import com.example.data.model.MatchRecord
import com.example.data.model.MemberProfile
import com.example.ui.components.ProfileAvatar
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GoldSoftContainer
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.viewmodel.CovenantUiState

@Composable
fun MatchesTab(
    state: CovenantUiState,
    onOpenChat: (String) -> Unit,
    onOpenProfileDetail: (MemberProfile) -> Unit,
    onAcceptRequest: (ConnectionRequest) -> Unit,
    onDeclineRequest: (ConnectionRequest) -> Unit
) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    val incoming = state.incomingRequests
    val outgoing = state.outgoingRequests
    val matches = state.visibleMatches

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = PureWhite,
            contentColor = NavyDeep,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
                    color = GoldRoyal
                )
            }
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                modifier = Modifier.testTag("matches_subtab_mutual"),
                text = {
                    Text(
                        text = "Matches (${matches.size})",
                        fontWeight = if (selectedSubTab == 0) FontWeight.Bold else FontWeight.Medium
                    )
                }
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                modifier = Modifier.testTag("matches_subtab_requests"),
                text = {
                    Text(
                        text = "Requests (${incoming.size + outgoing.size})",
                        fontWeight = if (selectedSubTab == 1) FontWeight.Bold else FontWeight.Medium
                    )
                }
            )
        }

        if (selectedSubTab == 0) {
            if (matches.isEmpty()) {
                EmptyMatchesPlaceholder(
                    title = "No Mutual Matches Yet",
                    body = "When two members express mutual interest, your match appears here so you can begin messaging."
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(matches, key = { it.id }) { match ->
                        MutualMatchCard(
                            match = match,
                            onMessageClick = { onOpenChat(match.id) },
                            onViewProfileClick = { onOpenProfileDetail(match.matchedMember) }
                        )
                    }
                }
            }
        } else {
            if (incoming.isEmpty() && outgoing.isEmpty()) {
                EmptyMatchesPlaceholder(
                    title = "No Pending Connection Requests",
                    body = "Explore Discover to express interest in fellow Christian singles, or check back for incoming requests."
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (incoming.isNotEmpty()) {
                        item {
                            Text(
                                text = "Incoming Connection Requests",
                                style = MaterialTheme.typography.titleMedium,
                                color = NavyDeep
                            )
                        }
                        items(incoming, key = { it.id }) { req ->
                            IncomingRequestCard(
                                request = req,
                                onViewProfile = { onOpenProfileDetail(req.senderProfile) },
                                onAccept = { onAcceptRequest(req) },
                                onDecline = { onDeclineRequest(req) }
                            )
                        }
                    }
                    if (outgoing.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Sent Requests",
                                style = MaterialTheme.typography.titleMedium,
                                color = NavyDeep
                            )
                        }
                        items(outgoing, key = { it.id }) { req ->
                            OutgoingRequestCard(
                                request = req,
                                onViewProfile = { onOpenProfileDetail(req.senderProfile) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MutualMatchCard(
    match: MatchRecord,
    onMessageClick: () -> Unit,
    onViewProfileClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onViewProfileClick)
            .testTag("match_card_${match.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, GoldRoyal.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProfileAvatar(profile = match.matchedMember, size = 64.dp, showGoldRing = true)
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${match.matchedMember.fullName}, ${match.matchedMember.age}",
                    style = MaterialTheme.typography.titleMedium,
                    color = NavyDeep
                )
                Text(
                    text = "${match.matchedMember.denomination} • ${match.matchedMember.location}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = match.matchedAtLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = GoldDeep
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onMessageClick,
                colors = ButtonDefaults.buttonColors(containerColor = NavyDeep),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("match_chat_button_${match.id}")
            ) {
                Icon(Icons.Filled.ChatBubble, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Chat")
            }
        }
    }
}

@Composable
private fun IncomingRequestCard(
    request: ConnectionRequest,
    onViewProfile: () -> Unit,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onViewProfile),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(profile = request.senderProfile, size = 58.dp, showGoldRing = true)
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${request.senderProfile.fullName}, ${request.senderProfile.age}",
                        style = MaterialTheme.typography.titleMedium,
                        color = NavyDeep
                    )
                    Text(
                        text = "${request.senderProfile.denomination} • ${request.senderProfile.location}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondarySlate
                    )
                    Text(
                        text = request.createdAtLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldDeep
                    )
                }
            }
            if (request.note.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GoldSoftContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "\"${request.note}\"",
                        style = MaterialTheme.typography.bodySmall.copy(fontStyle = FontStyle.Italic),
                        color = NavyDeep,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onDecline,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("decline_request_${request.id}"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Decline")
                }
                Button(
                    onClick = onAccept,
                    modifier = Modifier
                        .weight(1.4f)
                        .height(48.dp)
                        .testTag("accept_request_${request.id}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldRoyal,
                        contentColor = NavyDeep
                    )
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Accept & Match", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun OutgoingRequestCard(
    request: ConnectionRequest,
    onViewProfile: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onViewProfile),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProfileAvatar(profile = request.senderProfile, size = 50.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = request.senderProfile.fullName,
                    style = MaterialTheme.typography.titleSmall,
                    color = NavyDeep
                )
                Text(
                    text = "${request.senderProfile.denomination} • ${request.createdAtLabel}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondarySlate,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Surface(
                shape = RoundedCornerShape(50),
                color = GoldSoftContainer
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.HourglassTop,
                        contentDescription = null,
                        tint = GoldDeep,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Pending",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldDeep
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyMatchesPlaceholder(
    title: String,
    body: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Filled.FavoriteBorder,
                contentDescription = null,
                tint = GoldRoyal,
                modifier = Modifier.size(52.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = NavyDeep,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = body,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondarySlate,
                textAlign = TextAlign.Center
            )
        }
    }
}
