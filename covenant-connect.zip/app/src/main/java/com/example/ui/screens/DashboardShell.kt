package com.example.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.MemberProfile
import com.example.data.remote.SupabaseConfig
import com.example.ui.components.BlockReportDialog
import com.example.ui.components.CovenantCrestLogo
import com.example.ui.components.MatchCelebrationDialog
import com.example.ui.components.NotificationBellButton
import com.example.ui.components.NotificationsSheet
import com.example.ui.components.ProfileDetailSheet
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GoldSoftContainer
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.viewmodel.CovenantUiState
import com.example.ui.viewmodel.CovenantViewModel
import com.example.ui.viewmodel.DashboardTab

private data class NavItemSpec(
    val tab: DashboardTab,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val badgeCount: Int = 0
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardShell(
    state: CovenantUiState,
    viewModel: CovenantViewModel,
    onSignedOut: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    var showFiltersSheet by remember { mutableStateOf(false) }
    var showNotificationsSheet by remember { mutableStateOf(false) }
    var showSafetySheet by remember { mutableStateOf(false) }
    var showSupabaseInfoDialog by remember { mutableStateOf(false) }
    var safetyTargetMember by remember { mutableStateOf<MemberProfile?>(null) }

    LaunchedEffect(state.statusBannerMessage) {
        val message = state.statusBannerMessage
        if (!message.isNullOrBlank()) {
            snackbarHostState.showSnackbar(message)
            viewModel.clearStatusBanner()
        }
    }

    val navItems = listOf(
        NavItemSpec(DashboardTab.HOME, Icons.Filled.Home, Icons.Outlined.Home),
        NavItemSpec(DashboardTab.DISCOVER, Icons.Filled.Explore, Icons.Outlined.Explore),
        NavItemSpec(
            DashboardTab.MATCHES,
            Icons.Filled.Favorite,
            Icons.Outlined.FavoriteBorder,
            badgeCount = state.incomingRequests.size
        ),
        NavItemSpec(
            DashboardTab.MESSAGES,
            Icons.Filled.ChatBubble,
            Icons.Outlined.ChatBubbleOutline,
            badgeCount = state.unreadMessageCount
        ),
        NavItemSpec(DashboardTab.PROFILE, Icons.Filled.Person, Icons.Outlined.Person)
    )

    val isInsideChat = state.activeTab == DashboardTab.MESSAGES && state.activeChatMatchId != null

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CovenantCrestLogo(size = 34.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "COVENANT CONNECT",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = PureWhite,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (state.isPreviewMode) "Preview Mode • ${state.activeTab.label}" else state.activeTab.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldBright
                                )
                            }
                        }
                    },
                    actions = {
                        NotificationBellButton(
                            unreadCount = state.unreadNotificationCount,
                            onClick = { showNotificationsSheet = true }
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDeep)
                )
            },
            bottomBar = {
                if (!useRail && !isInsideChat) {
                    NavigationBar(
                        containerColor = PureWhite,
                        contentColor = NavyDeep,
                        windowInsets = WindowInsets(0, 0, 0, 0),
                        modifier = Modifier.navigationBarsPadding()
                    ) {
                        navItems.forEach { item ->
                            val selected = state.activeTab == item.tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(item.tab) },
                                modifier = Modifier.testTag("nav_tab_${item.tab.name.lowercase()}"),
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (item.badgeCount > 0) {
                                                Badge(
                                                    containerColor = GoldRoyal,
                                                    contentColor = NavyDeep
                                                ) {
                                                    Text(item.badgeCount.toString())
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.tab.label
                                        )
                                    }
                                },
                                label = {
                                    Text(
                                        text = item.tab.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NavyDeep,
                                    selectedTextColor = NavyDeep,
                                    indicatorColor = GoldSoftContainer,
                                    unselectedIconColor = TextSecondarySlate,
                                    unselectedTextColor = TextSecondarySlate
                                )
                            )
                        }
                    }
                }
            },
            containerColor = IvoryBackground
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = PureWhite,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        navItems.forEach { item ->
                            val selected = state.activeTab == item.tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(item.tab) },
                                modifier = Modifier.testTag("rail_tab_${item.tab.name.lowercase()}"),
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (item.badgeCount > 0) {
                                                Badge(
                                                    containerColor = GoldRoyal,
                                                    contentColor = NavyDeep
                                                ) {
                                                    Text(item.badgeCount.toString())
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.tab.label
                                        )
                                    }
                                },
                                label = { Text(item.tab.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = NavyDeep,
                                    selectedTextColor = NavyDeep,
                                    indicatorColor = GoldSoftContainer,
                                    unselectedIconColor = TextSecondarySlate,
                                    unselectedTextColor = TextSecondarySlate
                                )
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    when (state.activeTab) {
                        DashboardTab.HOME -> HomeTab(
                            state = state,
                            onSelectTab = viewModel::selectTab,
                            onOpenProfileDetail = viewModel::openProfileDetail,
                            onOpenSafetyCenter = { showSafetySheet = true },
                            onOpenSupabaseInfo = { showSupabaseInfoDialog = true }
                        )
                        DashboardTab.DISCOVER -> DiscoverTab(
                            state = state,
                            onOpenFilters = { showFiltersSheet = true },
                            onResetFilters = viewModel::resetFilters,
                            onOpenProfileDetail = viewModel::openProfileDetail,
                            onExpressInterest = { viewModel.expressInterest(it) },
                            onPass = viewModel::passProfile
                        )
                        DashboardTab.MATCHES -> MatchesTab(
                            state = state,
                            onOpenChat = viewModel::openChat,
                            onOpenProfileDetail = viewModel::openProfileDetail,
                            onAcceptRequest = viewModel::acceptConnectionRequest,
                            onDeclineRequest = viewModel::declineConnectionRequest
                        )
                        DashboardTab.MESSAGES -> MessagesTab(
                            state = state,
                            onOpenChat = viewModel::openChat,
                            onCloseChat = viewModel::closeChat,
                            onSendMessage = viewModel::sendChatMessage,
                            onOpenProfileDetail = viewModel::openProfileDetail,
                            onReportOrBlock = { safetyTargetMember = it }
                        )
                        DashboardTab.PROFILE -> ProfileTab(
                            state = state,
                            onUpdatePhotoUri = viewModel::updatePickedPhoto,
                            onUpdateProfile = viewModel::updateCurrentUserProfile,
                            onOpenSafetyCenter = { showSafetySheet = true },
                            onSignOut = { viewModel.signOut(onSignedOut) }
                        )
                    }
                }
            }
        }
    }

    // Profile Detail Sheet
    state.selectedProfileForDetail?.let { detailProfile ->
        val matchingRecord = state.visibleMatches.firstOrNull { it.matchedMember.id == detailProfile.id }
        ProfileDetailSheet(
            profile = detailProfile,
            isAlreadyMatched = matchingRecord != null,
            onDismiss = { viewModel.openProfileDetail(null) },
            onExpressInterest = { note -> viewModel.expressInterest(detailProfile, note) },
            onPass = { viewModel.passProfile(detailProfile) },
            onOpenChat = matchingRecord?.let { { viewModel.openChat(it.id) } },
            onReportOrBlock = { safetyTargetMember = detailProfile }
        )
    }

    // Filters Sheet
    if (showFiltersSheet) {
        DiscoverFiltersSheet(
            currentFilters = state.filters,
            onDismiss = { showFiltersSheet = false },
            onApply = viewModel::updateFilters,
            onReset = viewModel::resetFilters
        )
    }

    // Notifications Sheet
    if (showNotificationsSheet) {
        NotificationsSheet(
            notifications = state.notifications,
            onDismiss = { showNotificationsSheet = false },
            onMarkAllRead = viewModel::markAllNotificationsRead,
            onTapNotification = { notif ->
                showNotificationsSheet = false
                viewModel.handleNotificationTap(notif)
            }
        )
    }

    // Safety & Privacy Sheet
    if (showSafetySheet) {
        SafetyPrivacySheet(
            state = state,
            onDismiss = { showSafetySheet = false },
            onUpdatePrivacy = viewModel::updatePrivacySettings,
            onUnblockUser = viewModel::unblockUser
        )
    }

    // Block / Report Dialog
    safetyTargetMember?.let { target ->
        BlockReportDialog(
            member = target,
            onDismiss = { safetyTargetMember = null },
            onBlockOnly = {
                viewModel.blockUser(target)
                safetyTargetMember = null
            },
            onSubmitReport = { reason, details, alsoBlock ->
                viewModel.reportUser(target, reason, details, alsoBlock)
                safetyTargetMember = null
            }
        )
    }

    // Mutual Match Celebration Dialog
    state.celebratedMatch?.let { match ->
        MatchCelebrationDialog(
            match = match,
            onDismiss = viewModel::dismissMatchCelebration,
            onStartChat = { viewModel.openChat(match.id) }
        )
    }

    // Supabase Info Dialog
    if (showSupabaseInfoDialog) {
        AlertDialog(
            onDismissRequest = { showSupabaseInfoDialog = false },
            title = { Text("Supabase Integration Status") },
            text = {
                Column {
                    Text(
                        text = if (state.isSupabaseConfigured && state.isAuthenticatedLive) {
                            "Connected to your Supabase project."
                        } else {
                            "Currently running in UI Preview Mode with realistic sample profiles. Add SUPABASE_URL and SUPABASE_ANON_KEY in AI Studio Secrets to enable live authentication, matchmaking, and real-time tables:"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.padding(top = 8.dp))
                    SupabaseConfig.expectedTables.forEach { table ->
                        Text(
                            text = "• ${table.tableName}",
                            style = MaterialTheme.typography.labelMedium,
                            color = NavyDeep
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSupabaseInfoDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}
