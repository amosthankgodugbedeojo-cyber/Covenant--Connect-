package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val CovenantLightColorScheme = lightColorScheme(
    primary = NavyDeep,
    onPrimary = PureWhite,
    primaryContainer = NavySoftContainer,
    onPrimaryContainer = NavyDeep,
    secondary = GoldRoyal,
    onSecondary = NavyDeep,
    secondaryContainer = GoldSoftContainer,
    onSecondaryContainer = GoldDeep,
    tertiary = NavyMedium,
    onTertiary = PureWhite,
    tertiaryContainer = SoftSlateSurface,
    onTertiaryContainer = NavyDeep,
    background = IvoryBackground,
    onBackground = TextPrimaryNavy,
    surface = PureWhite,
    onSurface = TextPrimaryNavy,
    surfaceVariant = SoftSlateSurface,
    onSurfaceVariant = TextSecondarySlate,
    outline = OutlineMist,
    outlineVariant = GoldBorder,
    error = AlertCrimson,
    onError = PureWhite,
    errorContainer = AlertCrimsonContainer,
    onErrorContainer = AlertCrimson
)

private val CovenantDarkColorScheme = darkColorScheme(
    primary = GoldBright,
    onPrimary = NavyDeep,
    primaryContainer = NavyMedium,
    onPrimaryContainer = PureWhite,
    secondary = GoldRoyal,
    onSecondary = NavyDeep,
    secondaryContainer = DarkNavySurfaceHigh,
    onSecondaryContainer = GoldBright,
    tertiary = NavySoftContainer,
    onTertiary = NavyDeep,
    background = DarkNavyBackground,
    onBackground = PureWhite,
    surface = DarkNavySurface,
    onSurface = PureWhite,
    surfaceVariant = DarkNavySurfaceHigh,
    onSurfaceVariant = OutlineMist,
    outline = NavyMuted,
    outlineVariant = GoldDeep,
    error = AlertCrimsonContainer,
    onError = AlertCrimson
)

val CovenantShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun CovenantConnectTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) CovenantDarkColorScheme else CovenantLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = CovenantTypography,
        shapes = CovenantShapes,
        content = content
    )
}
