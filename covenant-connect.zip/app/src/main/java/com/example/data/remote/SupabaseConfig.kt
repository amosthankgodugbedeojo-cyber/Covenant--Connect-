package com.example.data.remote

import com.example.BuildConfig

data class SupabaseTableMapping(
    val tableName: String,
    val description: String,
    val isMappedInClient: Boolean = true
)

object SupabaseConfig {
    val supabaseUrl: String = BuildConfig.SUPABASE_URL.trim().trimEnd('/')
    val supabaseAnonKey: String = BuildConfig.SUPABASE_ANON_KEY.trim()

    val isConfigured: Boolean
        get() = supabaseUrl.startsWith("https://") &&
            !supabaseUrl.contains("YOUR_SUPABASE_URL") &&
            supabaseAnonKey.isNotBlank() &&
            !supabaseAnonKey.contains("YOUR_SUPABASE_ANON_KEY")

    val expectedTables: List<SupabaseTableMapping> = listOf(
        SupabaseTableMapping("profiles", "Member faith profiles, demographics & verification status"),
        SupabaseTableMapping("connection_requests", "Sent and incoming interest requests between singles"),
        SupabaseTableMapping("matches", "Mutual matches unlocking private Christian courtship chat"),
        SupabaseTableMapping("messages", "Private match chat messages with server timestamps"),
        SupabaseTableMapping("notifications", "Likes, mutual match alerts, and message notifications")
    )
}
