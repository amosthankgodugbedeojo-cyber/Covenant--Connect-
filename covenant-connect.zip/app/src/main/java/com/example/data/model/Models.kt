package com.example.data.model

import androidx.annotation.DrawableRes
import com.example.R

enum class Gender(val label: String) {
    FEMALE("Female"),
    MALE("Male")
}

enum class RelationshipIntent(val label: String) {
    MARRIAGE_MINDED("Marriage-Minded Courtship"),
    INTENTIONAL_DATING("Intentional Dating Toward Marriage"),
    FRIENDSHIP_FIRST("Christ-Centered Friendship First")
}

enum class Denomination(val label: String) {
    NON_DENOMINATIONAL("Non-Denominational"),
    BAPTIST("Baptist"),
    PENTECOSTAL("Pentecostal"),
    ANGLICAN("Anglican"),
    PRESBYTERIAN("Presbyterian"),
    METHODIST("Methodist"),
    CATHOLIC("Catholic"),
    LUTHERAN("Lutheran"),
    REFORMED("Reformed")
}

enum class RequestStatus {
    PENDING,
    ACCEPTED,
    DECLINED
}

enum class NotificationType(val label: String) {
    LIKE("Interest"),
    MATCH("Match"),
    MESSAGE("Message")
}

enum class ReportReason(val label: String) {
    INAPPROPRIATE_CONTENT("Inappropriate Content"),
    HARASSMENT("Harassment or Disrespect"),
    FAKE_PROFILE("Suspected Fake or Scam Profile"),
    OFF_PLATFORM_SOLICITATION("Unsolicited Financial / Off-Platform Request"),
    OTHER("Other Safety Concern")
}

data class MemberProfile(
    val id: String,
    val fullName: String,
    val email: String = "",
    val dateOfBirth: String = "1998-04-12",
    val age: Int,
    val gender: Gender,
    val location: String,
    val denomination: String,
    val occupation: String,
    val education: String,
    val bio: String,
    val relationshipIntent: RelationshipIntent,
    val faithAndValues: List<String>,
    val favoriteVerse: String = "",
    val avatarUrl: String? = null,
    @DrawableRes val localAvatarRes: Int? = null,
    val localPickedPhotoUri: String? = null,
    val emailVerified: Boolean = false,
    val isSampleProfile: Boolean = true
)

data class ConnectionRequest(
    val id: String,
    val senderId: String,
    val receiverId: String,
    val senderProfile: MemberProfile,
    val status: RequestStatus,
    val note: String,
    val createdAtLabel: String,
    val isIncoming: Boolean
)

data class MatchRecord(
    val id: String,
    val matchedMember: MemberProfile,
    val matchedAtLabel: String,
    val lastMessagePreview: String?,
    val lastMessageTime: String?,
    val unreadCount: Int = 0
)

data class ChatMessage(
    val id: String,
    val matchId: String,
    val senderId: String,
    val content: String,
    val timestampLabel: String,
    val isFromCurrentUser: Boolean,
    val isPreviewOnly: Boolean = true
)

data class AppNotification(
    val id: String,
    val type: NotificationType,
    val title: String,
    val body: String,
    val timestampLabel: String,
    val isRead: Boolean = false,
    val relatedMemberId: String? = null,
    val relatedMatchId: String? = null
)

data class DiscoverFilters(
    val minAge: Int = 21,
    val maxAge: Int = 45,
    val locationQuery: String = "",
    val selectedDenomination: String? = null
)

data class PrivacySettings(
    val showCityOnly: Boolean = true,
    val hideEmailFromMembers: Boolean = true,
    val showActiveStatus: Boolean = true,
    val allowPrayerNotesOnLikes: Boolean = true
)

data class SafetyReportRecord(
    val id: String,
    val reportedUserId: String,
    val reportedUserName: String,
    val reason: ReportReason,
    val details: String,
    val timestampLabel: String
)

object SampleData {
    const val CURRENT_PREVIEW_USER_ID = "preview_current_user"

    val defaultCurrentUser = MemberProfile(
        id = CURRENT_PREVIEW_USER_ID,
        fullName = "Joshua Carter",
        email = "joshua.carter@example.com",
        dateOfBirth = "1996-08-14",
        age = 30,
        gender = Gender.MALE,
        location = "Austin, TX",
        denomination = Denomination.NON_DENOMINATIONAL.label,
        occupation = "Civil Engineer",
        education = "B.S. Civil Engineering, Texas A&M",
        bio = "Grateful follower of Christ who loves leading a young adults small group, trail running, and weekend hospitality. Praying for a godly partner to build a joyful, faith-filled home.",
        relationshipIntent = RelationshipIntent.MARRIAGE_MINDED,
        faithAndValues = listOf("Daily Devotion", "Small Group Leader", "Marriage-Minded", "Missions & Service"),
        favoriteVerse = "Ecclesiastes 4:9-10 — Two are better than one, because they have a good return for their labor.",
        localAvatarRes = null,
        emailVerified = true,
        isSampleProfile = true
    )

    val graceProfile = MemberProfile(
        id = "sample_grace_01",
        fullName = "Grace Adeyemi",
        age = 27,
        gender = Gender.FEMALE,
        location = "Dallas, TX",
        denomination = Denomination.NON_DENOMINATIONAL.label,
        occupation = "Pediatric Nurse",
        education = "B.S.N. Nursing, Baylor University",
        bio = "Serving children in pediatric care is my calling. Outside the hospital I sing on our church worship team, bake sourdough, and cherish quiet mornings in the Psalms.",
        relationshipIntent = RelationshipIntent.MARRIAGE_MINDED,
        faithAndValues = listOf("Worship Team", "Weekly Church", "Biblical Family", "Hospitality"),
        favoriteVerse = "Proverbs 31:25 — She is clothed with strength and dignity; she can laugh at the days to come.",
        localAvatarRes = R.drawable.img_profile_grace,
        emailVerified = true,
        isSampleProfile = true
    )

    val danielProfile = MemberProfile(
        id = "sample_daniel_02",
        fullName = "Daniel Bennett",
        age = 29,
        gender = Gender.MALE,
        location = "Nashville, TN",
        denomination = Denomination.PRESBYTERIAN.label,
        occupation = "Financial Analyst",
        education = "M.B.A., Vanderbilt University",
        bio = "Passionate about stewardship, youth mentorship, and acoustic guitar. Hoping to meet a kind, Christ-centered woman who values deep conversation and serving our local church.",
        relationshipIntent = RelationshipIntent.INTENTIONAL_DATING,
        faithAndValues = listOf("Youth Mentor", "Daily Prayer", "Stewardship", "Marriage-Minded"),
        favoriteVerse = "Micah 6:8 — Act justly, love mercy, and walk humbly with your God.",
        localAvatarRes = R.drawable.img_profile_daniel,
        emailVerified = true,
        isSampleProfile = true
    )

    val hannahProfile = MemberProfile(
        id = "sample_hannah_03",
        fullName = "Hannah Whitaker",
        age = 25,
        gender = Gender.FEMALE,
        location = "Charlotte, NC",
        denomination = Denomination.BAPTIST.label,
        occupation = "Elementary School Teacher",
        education = "M.Ed., Liberty University",
        bio = "Teaching third graders brings me daily joy. On Sundays you will find me teaching Sunday school and sharing dinner with church family. Seeking a faithful, intentional courtship.",
        relationshipIntent = RelationshipIntent.MARRIAGE_MINDED,
        faithAndValues = listOf("Children's Ministry", "Scripture Study", "Kindness", "Family-Focused"),
        favoriteVerse = "Colossians 3:14 — And over all these virtues put on love, which binds them all together in perfect unity.",
        localAvatarRes = R.drawable.img_profile_hannah,
        emailVerified = true,
        isSampleProfile = true
    )

    val samuelProfile = MemberProfile(
        id = "sample_samuel_04",
        fullName = "Samuel Okafor",
        age = 31,
        gender = Gender.MALE,
        location = "Atlanta, GA",
        denomination = Denomination.PENTECOSTAL.label,
        occupation = "Software Architect",
        education = "M.S. Computer Science, Georgia Tech",
        bio = "Faith anchors everything I build and do. I serve in our church hospitality ministry, enjoy mentoring young men, and love coastal road trips.",
        relationshipIntent = RelationshipIntent.MARRIAGE_MINDED,
        faithAndValues = listOf("Prayer Partner", "Hospitality Ministry", "Integrity", "Biblical Values"),
        favoriteVerse = "Joshua 24:15 — As for me and my household, we will serve the Lord.",
        localAvatarRes = R.drawable.img_profile_samuel,
        emailVerified = true,
        isSampleProfile = true
    )

    val ruthProfile = MemberProfile(
        id = "sample_ruth_05",
        fullName = "Ruth Morales",
        age = 28,
        gender = Gender.FEMALE,
        location = "San Antonio, TX",
        denomination = Denomination.ANGLICAN.label,
        occupation = "Architect",
        education = "M.Arch., University of Texas",
        bio = "Drawn to beauty in sacred spaces, community outreach, and slow Saturday coffee. Looking for a humble, prayerful partner ready to walk in grace together.",
        relationshipIntent = RelationshipIntent.INTENTIONAL_DATING,
        faithAndValues = listOf("Community Outreach", "Liturgical Worship", "Creative Arts", "Patience"),
        favoriteVerse = "1 Corinthians 13:4-7 — Love is patient, love is kind.",
        localAvatarRes = null,
        emailVerified = true,
        isSampleProfile = true
    )

    val sampleDiscoverProfiles = listOf(
        graceProfile,
        hannahProfile,
        danielProfile,
        samuelProfile,
        ruthProfile
    )

    val sampleMatches = listOf(
        MatchRecord(
            id = "match_grace_01",
            matchedMember = graceProfile,
            matchedAtLabel = "Matched 2 days ago",
            lastMessagePreview = "Thank you for the kind note! Which worship songs is your church singing lately?",
            lastMessageTime = "10:24 AM",
            unreadCount = 1
        ),
        MatchRecord(
            id = "match_hannah_02",
            matchedMember = hannahProfile,
            matchedAtLabel = "Matched 5 days ago",
            lastMessagePreview = "Teaching third graders definitely keeps me praying every morning!",
            lastMessageTime = "Yesterday",
            unreadCount = 0
        )
    )

    val sampleRequests = listOf(
        ConnectionRequest(
            id = "req_in_01",
            senderId = ruthProfile.id,
            receiverId = CURRENT_PREVIEW_USER_ID,
            senderProfile = ruthProfile,
            status = RequestStatus.PENDING,
            note = "Loved reading about your small group ministry! Would love to connect and share testimonies.",
            createdAtLabel = "3 hours ago",
            isIncoming = true
        ),
        ConnectionRequest(
            id = "req_out_01",
            senderId = CURRENT_PREVIEW_USER_ID,
            receiverId = danielProfile.id,
            senderProfile = danielProfile,
            status = RequestStatus.PENDING,
            note = "Great to see another brother passionate about youth mentorship!",
            createdAtLabel = "1 day ago",
            isIncoming = false
        )
    )

    val sampleMessages = mapOf(
        "match_grace_01" to listOf(
            ChatMessage(
                id = "msg_1",
                matchId = "match_grace_01",
                senderId = CURRENT_PREVIEW_USER_ID,
                content = "Hi Grace! It was encouraging to read about your pediatric nursing ministry and worship team service.",
                timestampLabel = "9:42 AM",
                isFromCurrentUser = true
            ),
            ChatMessage(
                id = "msg_2",
                matchId = "match_grace_01",
                senderId = graceProfile.id,
                content = "Thank you so much, Joshua! I really appreciated your favorite verse from Ecclesiastes too.",
                timestampLabel = "10:15 AM",
                isFromCurrentUser = false
            ),
            ChatMessage(
                id = "msg_3",
                matchId = "match_grace_01",
                senderId = graceProfile.id,
                content = "Thank you for the kind note! Which worship songs is your church singing lately?",
                timestampLabel = "10:24 AM",
                isFromCurrentUser = false
            )
        ),
        "match_hannah_02" to listOf(
            ChatMessage(
                id = "msg_4",
                matchId = "match_hannah_02",
                senderId = CURRENT_PREVIEW_USER_ID,
                content = "Hello Hannah! How has this school semester been going for your third-grade class?",
                timestampLabel = "Yesterday, 4:10 PM",
                isFromCurrentUser = true
            ),
            ChatMessage(
                id = "msg_5",
                matchId = "match_hannah_02",
                senderId = hannahProfile.id,
                content = "Teaching third graders definitely keeps me praying every morning!",
                timestampLabel = "Yesterday, 6:05 PM",
                isFromCurrentUser = false
            )
        )
    )

    val sampleNotifications = listOf(
        AppNotification(
            id = "notif_1",
            type = NotificationType.MESSAGE,
            title = "New message from Grace Adeyemi",
            body = "Which worship songs is your church singing lately?",
            timestampLabel = "10:24 AM",
            isRead = false,
            relatedMemberId = graceProfile.id,
            relatedMatchId = "match_grace_01"
        ),
        AppNotification(
            id = "notif_2",
            type = NotificationType.LIKE,
            title = "New Connection Request",
            body = "Ruth Morales expressed interest in connecting with you.",
            timestampLabel = "3 hours ago",
            isRead = false,
            relatedMemberId = ruthProfile.id
        ),
        AppNotification(
            id = "notif_3",
            type = NotificationType.MATCH,
            title = "Covenant Match Confirmed",
            body = "You and Hannah Whitaker are now connected! Send an encouraging message.",
            timestampLabel = "5 days ago",
            isRead = true,
            relatedMemberId = hannahProfile.id,
            relatedMatchId = "match_hannah_02"
        )
    )
}
