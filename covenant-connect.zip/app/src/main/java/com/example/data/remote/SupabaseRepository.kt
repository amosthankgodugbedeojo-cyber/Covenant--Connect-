package com.example.data.remote

import com.example.data.model.Gender
import com.example.data.model.MemberProfile
import com.example.data.model.RelationshipIntent
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

sealed class SupabaseResult<out T> {
    data class Success<T>(val data: T) : SupabaseResult<T>()
    data object NotConfigured : SupabaseResult<Nothing>()
    data class Error(val message: String) : SupabaseResult<Nothing>()
}

class SupabaseRepository {
    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
    }

    private val okHttpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private val apiService: SupabaseApiService? by lazy {
        if (!SupabaseConfig.isConfigured) {
            null
        } else {
            Retrofit.Builder()
                .baseUrl("${SupabaseConfig.supabaseUrl}/")
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(SupabaseApiService::class.java)
        }
    }

    private var activeAccessToken: String? = null
    private var activeUserId: String? = null

    fun hasLiveSession(): Boolean = SupabaseConfig.isConfigured && !activeAccessToken.isNullOrBlank()

    suspend fun signUp(
        fullName: String,
        email: String,
        password: String,
        dateOfBirth: String,
        age: Int,
        gender: Gender,
        location: String,
        denomination: String
    ): SupabaseResult<SupabaseAuthResponse> {
        val service = apiService ?: return SupabaseResult.NotConfigured
        return try {
            val response = service.signUp(
                apiKey = SupabaseConfig.supabaseAnonKey,
                body = SupabaseAuthRequest(
                    email = email,
                    password = password,
                    data = mapOf(
                        "full_name" to fullName,
                        "date_of_birth" to dateOfBirth,
                        "gender" to gender.label,
                        "location" to location,
                        "denomination" to denomination
                    )
                )
            )
            if (response.isSuccessful && response.body() != null) {
                val authBody = response.body()!!
                activeAccessToken = authBody.accessToken
                activeUserId = authBody.user?.id
                if (!authBody.accessToken.isNullOrBlank() && authBody.user?.id != null) {
                    service.upsertProfile(
                        apiKey = SupabaseConfig.supabaseAnonKey,
                        bearerToken = "Bearer ${authBody.accessToken}",
                        profile = ProfileDto(
                            id = authBody.user.id,
                            fullName = fullName,
                            email = email,
                            dateOfBirth = dateOfBirth,
                            age = age,
                            gender = gender.label,
                            location = location,
                            denomination = denomination,
                            relationshipIntent = RelationshipIntent.MARRIAGE_MINDED.label,
                            emailVerified = authBody.user.emailConfirmedAt != null
                        )
                    )
                }
                SupabaseResult.Success(authBody)
            } else {
                SupabaseResult.Error("Sign up could not be completed (${response.code()}). Please verify your email or Supabase Auth settings.")
            }
        } catch (e: Exception) {
            SupabaseResult.Error("Network error while reaching Supabase: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    suspend fun signIn(email: String, password: String): SupabaseResult<SupabaseAuthResponse> {
        val service = apiService ?: return SupabaseResult.NotConfigured
        return try {
            val response = service.signInWithPassword(
                apiKey = SupabaseConfig.supabaseAnonKey,
                body = SupabaseAuthRequest(email = email, password = password)
            )
            if (response.isSuccessful && response.body() != null) {
                val authBody = response.body()!!
                activeAccessToken = authBody.accessToken
                activeUserId = authBody.user?.id
                SupabaseResult.Success(authBody)
            } else {
                SupabaseResult.Error("Sign in failed (${response.code()}). Check your credentials or confirm your email verification link.")
            }
        } catch (e: Exception) {
            SupabaseResult.Error("Unable to connect to Supabase: ${e.localizedMessage ?: "Network unavailable"}")
        }
    }

    suspend fun resendVerificationEmail(email: String): SupabaseResult<Unit> {
        val service = apiService ?: return SupabaseResult.NotConfigured
        return try {
            val response = service.resendVerification(
                apiKey = SupabaseConfig.supabaseAnonKey,
                body = SupabaseResendRequest(email = email)
            )
            if (response.isSuccessful) {
                SupabaseResult.Success(Unit)
            } else {
                SupabaseResult.Error("Could not resend verification email (${response.code()}).")
            }
        } catch (e: Exception) {
            SupabaseResult.Error("Unable to reach Supabase: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    suspend fun fetchLiveProfiles(): SupabaseResult<List<MemberProfile>> {
        val service = apiService ?: return SupabaseResult.NotConfigured
        val token = activeAccessToken ?: return SupabaseResult.Error("No active Supabase session.")
        return try {
            val response = service.getProfiles(
                apiKey = SupabaseConfig.supabaseAnonKey,
                bearerToken = "Bearer $token"
            )
            if (response.isSuccessful) {
                val mapped = response.body().orEmpty().map { dto ->
                    MemberProfile(
                        id = dto.id,
                        fullName = dto.fullName,
                        email = dto.email.orEmpty(),
                        dateOfBirth = dto.dateOfBirth ?: "1998-01-01",
                        age = dto.age ?: 26,
                        gender = if (dto.gender.equals("Male", ignoreCase = true)) Gender.MALE else Gender.FEMALE,
                        location = dto.location ?: "Location private",
                        denomination = dto.denomination ?: "Non-Denominational",
                        occupation = dto.occupation ?: "Member",
                        education = dto.education ?: "Not listed",
                        bio = dto.bio ?: "",
                        relationshipIntent = RelationshipIntent.entries.find {
                            it.label.equals(dto.relationshipIntent, ignoreCase = true)
                        } ?: RelationshipIntent.MARRIAGE_MINDED,
                        faithAndValues = dto.faithValues.orEmpty(),
                        favoriteVerse = dto.favoriteVerse.orEmpty(),
                        avatarUrl = dto.avatarUrl,
                        emailVerified = dto.emailVerified ?: false,
                        isSampleProfile = false
                    )
                }
                SupabaseResult.Success(mapped)
            } else {
                SupabaseResult.Error("Could not load profiles (${response.code()}).")
            }
        } catch (e: Exception) {
            SupabaseResult.Error("Network error loading profiles: ${e.localizedMessage ?: "Unknown"}")
        }
    }

    suspend fun sendLiveConnectionRequest(
        senderId: String,
        receiverId: String,
        note: String
    ): SupabaseResult<Unit> {
        val service = apiService ?: return SupabaseResult.NotConfigured
        val token = activeAccessToken ?: return SupabaseResult.Error("Sign in required.")
        return try {
            val response = service.createConnectionRequest(
                apiKey = SupabaseConfig.supabaseAnonKey,
                bearerToken = "Bearer $token",
                request = ConnectionRequestDto(
                    senderId = senderId,
                    receiverId = receiverId,
                    status = "pending",
                    note = note
                )
            )
            if (response.isSuccessful) SupabaseResult.Success(Unit)
            else SupabaseResult.Error("Request failed (${response.code()}).")
        } catch (e: Exception) {
            SupabaseResult.Error("Network error: ${e.localizedMessage ?: "Unknown"}")
        }
    }

    suspend fun sendLiveMessage(
        matchId: String,
        senderId: String,
        content: String
    ): SupabaseResult<Unit> {
        val service = apiService ?: return SupabaseResult.NotConfigured
        val token = activeAccessToken ?: return SupabaseResult.Error("Sign in required.")
        return try {
            val response = service.sendMessage(
                apiKey = SupabaseConfig.supabaseAnonKey,
                bearerToken = "Bearer $token",
                message = MessageDto(
                    matchId = matchId,
                    senderId = senderId,
                    content = content
                )
            )
            if (response.isSuccessful) SupabaseResult.Success(Unit)
            else SupabaseResult.Error("Message send failed (${response.code()}).")
        } catch (e: Exception) {
            SupabaseResult.Error("Network error: ${e.localizedMessage ?: "Unknown"}")
        }
    }

    fun signOut() {
        activeAccessToken = null
        activeUserId = null
    }
}
