package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class SupabaseAuthRequest(
    val email: String,
    val password: String,
    val data: Map<String, String>? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseResendRequest(
    val type: String = "signup",
    val email: String
)

@JsonClass(generateAdapter = true)
data class SupabaseUserDto(
    val id: String,
    val email: String? = null,
    @Json(name = "email_confirmed_at") val emailConfirmedAt: String? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseAuthResponse(
    @Json(name = "access_token") val accessToken: String? = null,
    @Json(name = "refresh_token") val refreshToken: String? = null,
    val user: SupabaseUserDto? = null
)

@JsonClass(generateAdapter = true)
data class ProfileDto(
    val id: String,
    @Json(name = "full_name") val fullName: String,
    val email: String? = null,
    @Json(name = "date_of_birth") val dateOfBirth: String? = null,
    val age: Int? = null,
    val gender: String? = null,
    val location: String? = null,
    val denomination: String? = null,
    val occupation: String? = null,
    val education: String? = null,
    val bio: String? = null,
    @Json(name = "relationship_intent") val relationshipIntent: String? = null,
    @Json(name = "faith_values") val faithValues: List<String>? = null,
    @Json(name = "favorite_verse") val favoriteVerse: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
    @Json(name = "email_verified") val emailVerified: Boolean? = null
)

@JsonClass(generateAdapter = true)
data class ConnectionRequestDto(
    val id: String? = null,
    @Json(name = "sender_id") val senderId: String,
    @Json(name = "receiver_id") val receiverId: String,
    val status: String = "pending",
    val note: String? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class MatchDto(
    val id: String? = null,
    @Json(name = "user_one_id") val userOneId: String,
    @Json(name = "user_two_id") val userTwoId: String,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class MessageDto(
    val id: String? = null,
    @Json(name = "match_id") val matchId: String,
    @Json(name = "sender_id") val senderId: String,
    val content: String,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class NotificationDto(
    val id: String? = null,
    @Json(name = "user_id") val userId: String,
    val type: String,
    val title: String,
    val body: String,
    @Json(name = "is_read") val isRead: Boolean = false,
    @Json(name = "created_at") val createdAt: String? = null
)

interface SupabaseApiService {
    // --- Supabase Auth ---
    @POST("auth/v1/signup")
    suspend fun signUp(
        @Header("apikey") apiKey: String,
        @Body body: SupabaseAuthRequest
    ): Response<SupabaseAuthResponse>

    @POST("auth/v1/token?grant_type=password")
    suspend fun signInWithPassword(
        @Header("apikey") apiKey: String,
        @Body body: SupabaseAuthRequest
    ): Response<SupabaseAuthResponse>

    @POST("auth/v1/resend")
    suspend fun resendVerification(
        @Header("apikey") apiKey: String,
        @Body body: SupabaseResendRequest
    ): Response<Unit>

    // --- profiles table ---
    @GET("rest/v1/profiles?select=*")
    suspend fun getProfiles(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String
    ): Response<List<ProfileDto>>

    @POST("rest/v1/profiles")
    suspend fun upsertProfile(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Header("Prefer") prefer: String = "resolution=merge-duplicates,return=representation",
        @Body profile: ProfileDto
    ): Response<List<ProfileDto>>

    // --- connection_requests table ---
    @GET("rest/v1/connection_requests?select=*")
    suspend fun getConnectionRequests(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String
    ): Response<List<ConnectionRequestDto>>

    @POST("rest/v1/connection_requests")
    suspend fun createConnectionRequest(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Header("Prefer") prefer: String = "return=representation",
        @Body request: ConnectionRequestDto
    ): Response<List<ConnectionRequestDto>>

    @PATCH("rest/v1/connection_requests")
    suspend fun updateConnectionRequestStatus(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Query("id") idEqFilter: String,
        @Body statusPatch: Map<String, String>
    ): Response<Unit>

    // --- matches table ---
    @GET("rest/v1/matches?select=*")
    suspend fun getMatches(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String
    ): Response<List<MatchDto>>

    @POST("rest/v1/matches")
    suspend fun createMatch(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Header("Prefer") prefer: String = "return=representation",
        @Body match: MatchDto
    ): Response<List<MatchDto>>

    // --- messages table ---
    @GET("rest/v1/messages?select=*&order=created_at.asc")
    suspend fun getMessagesForMatch(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Query("match_id") matchIdEqFilter: String
    ): Response<List<MessageDto>>

    @POST("rest/v1/messages")
    suspend fun sendMessage(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Header("Prefer") prefer: String = "return=representation",
        @Body message: MessageDto
    ): Response<List<MessageDto>>

    // --- notifications table ---
    @GET("rest/v1/notifications?select=*&order=created_at.desc")
    suspend fun getNotifications(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Query("user_id") userIdEqFilter: String
    ): Response<List<NotificationDto>>

    @PATCH("rest/v1/notifications")
    suspend fun markAllNotificationsRead(
        @Header("apikey") apiKey: String,
        @Header("Authorization") bearerToken: String,
        @Query("user_id") userIdEqFilter: String,
        @Body patch: Map<String, Boolean> = mapOf("is_read" to true)
    ): Response<Unit>
}
