package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.DashboardShell
import com.example.ui.screens.EmailVerificationScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.RegisterScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.CovenantConnectTheme
import com.example.ui.viewmodel.CovenantViewModel

object Routes {
    const val WELCOME = "welcome"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val EMAIL_VERIFICATION = "email_verification"
    const val DASHBOARD = "dashboard"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CovenantConnectTheme(darkTheme = false) {
                val navController = rememberNavController()
                val viewModel: CovenantViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                NavHost(
                    navController = navController,
                    startDestination = Routes.WELCOME
                ) {
                    composable(Routes.WELCOME) {
                        WelcomeScreen(
                            isSupabaseConfigured = uiState.isSupabaseConfigured,
                            onNavigateToRegister = {
                                viewModel.clearAuthFeedback()
                                navController.navigate(Routes.REGISTER)
                            },
                            onNavigateToLogin = {
                                viewModel.clearAuthFeedback()
                                navController.navigate(Routes.LOGIN)
                            },
                            onExplorePreview = {
                                viewModel.enterPreviewMode {
                                    navController.navigate(Routes.DASHBOARD) {
                                        popUpTo(Routes.WELCOME) { inclusive = false }
                                    }
                                }
                            }
                        )
                    }

                    composable(Routes.LOGIN) {
                        LoginScreen(
                            isSupabaseConfigured = uiState.isSupabaseConfigured,
                            isLoading = uiState.isAuthLoading,
                            feedbackMessage = uiState.authFeedbackMessage,
                            isError = uiState.authIsError,
                            onBack = {
                                viewModel.clearAuthFeedback()
                                navController.popBackStack()
                            },
                            onSignIn = { email, password ->
                                viewModel.signIn(email, password) {
                                    navController.navigate(Routes.DASHBOARD) {
                                        popUpTo(Routes.WELCOME) { inclusive = true }
                                    }
                                }
                            },
                            onNavigateToRegister = {
                                viewModel.clearAuthFeedback()
                                navController.navigate(Routes.REGISTER) {
                                    popUpTo(Routes.LOGIN) { inclusive = true }
                                }
                            },
                            onExplorePreview = {
                                viewModel.enterPreviewMode {
                                    navController.navigate(Routes.DASHBOARD) {
                                        popUpTo(Routes.WELCOME) { inclusive = false }
                                    }
                                }
                            }
                        )
                    }

                    composable(Routes.REGISTER) {
                        RegisterScreen(
                            isSupabaseConfigured = uiState.isSupabaseConfigured,
                            isLoading = uiState.isAuthLoading,
                            feedbackMessage = uiState.authFeedbackMessage,
                            isError = uiState.authIsError,
                            onBack = {
                                viewModel.clearAuthFeedback()
                                navController.popBackStack()
                            },
                            onRegister = { name, email, pass, dob, age, gender, loc, denom, accepted ->
                                viewModel.register(
                                    fullName = name,
                                    email = email,
                                    password = pass,
                                    dateOfBirth = dob,
                                    age = age,
                                    gender = gender,
                                    location = loc,
                                    denomination = denom,
                                    acceptedCovenant = accepted,
                                    onVerificationNeeded = {
                                        navController.navigate(Routes.EMAIL_VERIFICATION) {
                                            popUpTo(Routes.REGISTER) { inclusive = true }
                                        }
                                    }
                                )
                            },
                            onNavigateToLogin = {
                                viewModel.clearAuthFeedback()
                                navController.navigate(Routes.LOGIN) {
                                    popUpTo(Routes.REGISTER) { inclusive = true }
                                }
                            },
                            onExplorePreview = {
                                viewModel.enterPreviewMode {
                                    navController.navigate(Routes.DASHBOARD) {
                                        popUpTo(Routes.WELCOME) { inclusive = false }
                                    }
                                }
                            }
                        )
                    }

                    composable(Routes.EMAIL_VERIFICATION) {
                        EmailVerificationScreen(
                            email = uiState.pendingVerificationEmail,
                            isLoading = uiState.isAuthLoading,
                            feedbackMessage = uiState.authFeedbackMessage,
                            isError = uiState.authIsError,
                            onResendEmail = viewModel::resendVerificationEmail,
                            onGoToLogin = {
                                viewModel.clearAuthFeedback()
                                navController.navigate(Routes.LOGIN) {
                                    popUpTo(Routes.EMAIL_VERIFICATION) { inclusive = true }
                                }
                            },
                            onExplorePreview = {
                                viewModel.enterPreviewMode {
                                    navController.navigate(Routes.DASHBOARD) {
                                        popUpTo(Routes.WELCOME) { inclusive = false }
                                    }
                                }
                            }
                        )
                    }

                    composable(Routes.DASHBOARD) {
                        DashboardShell(
                            state = uiState,
                            viewModel = viewModel,
                            onSignedOut = {
                                navController.navigate(Routes.WELCOME) {
                                    popUpTo(Routes.DASHBOARD) { inclusive = true }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
