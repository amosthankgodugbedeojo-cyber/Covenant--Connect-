package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.DiscoverFilters
import com.example.data.model.ReportReason
import com.example.data.model.SampleData
import com.example.ui.viewmodel.CovenantViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Covenant Connect", appName)
    }

    @Test
    fun `sign in without supabase keys does not pretend success`() {
        val viewModel = CovenantViewModel()
        var succeeded = false
        viewModel.signIn("grace@example.com", "password123") { succeeded = true }

        assertFalse(succeeded)
        val state = viewModel.uiState.value
        assertTrue(state.authIsError)
        assertTrue(state.authFeedbackMessage?.contains("Supabase") == true)
    }

    @Test
    fun `preview mode supports filtering accepting match messaging and blocking`() {
        val viewModel = CovenantViewModel()
        var entered = false
        viewModel.enterPreviewMode { entered = true }
        assertTrue(entered)
        assertTrue(viewModel.uiState.value.isPreviewMode)

        // Filter by denomination
        viewModel.updateFilters(DiscoverFilters(minAge = 24, maxAge = 35, selectedDenomination = "Baptist"))
        val filtered = viewModel.uiState.value.filteredDiscoverProfiles
        assertEquals(1, filtered.size)
        assertEquals(SampleData.hannahProfile.id, filtered.first().id)

        // Accept incoming request creates a match
        val incomingReq = viewModel.uiState.value.incomingRequests.first()
        val initialMatchCount = viewModel.uiState.value.visibleMatches.size
        viewModel.acceptConnectionRequest(incomingReq)
        assertEquals(initialMatchCount + 1, viewModel.uiState.value.visibleMatches.size)

        // Send message in chat
        val firstMatchId = viewModel.uiState.value.visibleMatches.first().id
        val initialMsgCount = viewModel.uiState.value.messagesByMatchId[firstMatchId]?.size ?: 0
        viewModel.sendChatMessage(firstMatchId, "Grace and peace!")
        assertEquals(initialMsgCount + 1, viewModel.uiState.value.messagesByMatchId[firstMatchId]?.size)

        // Report and block hides member
        viewModel.reportUser(SampleData.danielProfile, ReportReason.HARASSMENT, "Test report", alsoBlock = true)
        assertTrue(SampleData.danielProfile.id in viewModel.uiState.value.blockedUserIds)
    }
}
